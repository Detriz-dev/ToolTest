import React, { useEffect, useState } from 'react'
import { Check, X } from 'lucide-react'

interface ToastProps {
  message: string
  type?: 'success' | 'error' | 'info'
  isVisible: boolean
  onClose: () => void
  duration?: number
}

export function Toast({ message, type = 'success', isVisible, onClose, duration = 3000 }: ToastProps) {
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    if (isVisible) {
      setIsAnimating(true)
      const timer = setTimeout(() => {
        setIsAnimating(false)
        setTimeout(onClose, 300) // Wait for exit animation
      }, duration)

      return () => clearTimeout(timer)
    }
  }, [isVisible, duration, onClose])

  if (!isVisible && !isAnimating) return null

  const getToastStyles = () => {
    switch (type) {
      case 'success':
        return 'bg-green-500 text-white'
      case 'error':
        return 'bg-red-500 text-white'
      case 'info':
        return 'bg-blue-500 text-white'
      default:
        return 'bg-green-500 text-white'
    }
  }

  const getIcon = () => {
    switch (type) {
      case 'success':
        return <Check className="h-5 w-5" />
      case 'error':
        return <X className="h-5 w-5" />
      case 'info':
        return <Check className="h-5 w-5" />
      default:
        return <Check className="h-5 w-5" />
    }
  }

  return (
    <div
      className={`fixed top-20 left-1/2 transform -translate-x-1/2 z-50 flex items-center px-6 py-3 rounded-lg shadow-lg transition-all duration-300 ${
        isAnimating ? 'translate-y-0 opacity-100' : '-translate-y-2 opacity-0'
      } ${getToastStyles()}`}
    >
      <div className="mr-3">
        {getIcon()}
      </div>
      <span className="font-medium">{message}</span>
      <button
        onClick={() => {
          setIsAnimating(false)
          setTimeout(onClose, 300)
        }}
        className="ml-4 p-1 hover:bg-black/10 rounded-full transition-colors"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  )
}