import React from 'react'
import { useLocation } from 'react-router-dom'
import { Navigation } from './Navigation'

interface LayoutProps {
  children: React.ReactNode
}

export function Layout({ children }: LayoutProps) {
  const location = useLocation()
  const isAddVisitPage = location.pathname === '/add-visit'
  const isEditVisitPage = location.pathname.includes('/edit')
  const isVisitDetailsPage = location.pathname.startsWith('/customer-visit/') && !isEditVisitPage
  const hideBottomNav = isAddVisitPage || isEditVisitPage || isVisitDetailsPage

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation hideBottomNav={hideBottomNav} hideTopNav={isVisitDetailsPage} />
      <main className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${isAddVisitPage || isEditVisitPage || isVisitDetailsPage ? 'pt-20 lg:pt-8' : 'pt-24'} pb-[38px] lg:py-[38px] ${hideBottomNav ? 'mb-20 lg:mb-0' : 'mb-20 lg:mb-0'}`}>
        {(isAddVisitPage || isEditVisitPage) && (
          <h1 className="hidden lg:block text-3xl font-bold text-gray-900 mb-6">
            {isEditVisitPage ? 'Edit Visit' : 'Add Visit'}
          </h1>
        )}
        {children}
      </main>
    </div>
  )
}