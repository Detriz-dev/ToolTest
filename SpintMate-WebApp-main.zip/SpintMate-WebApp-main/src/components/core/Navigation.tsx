import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { 
  LayoutDashboard, 
  Settings, 
  Plus,
  UserCircle,
  Wrench,
  ArrowLeft,
  Search
} from 'lucide-react'

interface NavigationProps {
  hideBottomNav?: boolean
  hideTopNav?: boolean
}

export function Navigation({ hideBottomNav, hideTopNav }: NavigationProps) {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false)
  const location = useLocation()

  const isActive = (path: string) => location.pathname === path
  const isAddVisitPage = location.pathname === '/add-visit'
  const isEditVisitPage = location.pathname.includes('/edit')

  return (
    <>
      {/* Top Navigation Bar - Mobile */}
      {!hideTopNav && (
        <nav className="lg:hidden fixed top-0 left-0 right-0 bg-white shadow-sm z-50">
          <div className="px-4 h-16 flex justify-between items-center">
            {(isAddVisitPage || isEditVisitPage) ? (
              <div className="flex items-center flex-1">
                <button
                  onClick={() => window.history.back()}
                  className="p-2 -ml-2 text-blue-600 hover:text-blue-700 bg-white rounded-full hover:bg-gray-100 shadow-sm"
                >
                  <ArrowLeft className="h-5 w-5" />
                </button>
                <h1 className="text-lg font-semibold text-gray-900 ml-2">
                  {isEditVisitPage ? 'Edit Visit' : 'Add Visit'}
                </h1>
              </div>
            ) : (
              <>
                {/* Logo */}
                <Link 
                  to="/" 
                  className="flex items-center space-x-2 flex-shrink-0"
                >
                  <Wrench className="h-6 w-6 text-blue-600" />
                  <span className="text-xl font-bold text-gray-900">Sp1nMate</span>
                </Link>
                
                {/* User Menu */}
                <div className="relative flex-shrink-0">
                  <button
                    onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                    className="flex items-center justify-center h-10 w-10 rounded-full hover:bg-gray-100"
                  >
                    <UserCircle className="h-6 w-6 text-gray-700" />
                  </button>

                  {isUserMenuOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 ring-1 ring-black ring-opacity-5">
                      <Link
                        to="/settings"
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={() => setIsUserMenuOpen(false)}
                      >
                        Settings
                      </Link>
                      <button
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={() => {
                          setIsUserMenuOpen(false)
                          // Add logout logic here
                        }}
                      >
                        Sign out
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </nav>
      )}

      {/* Bottom Navigation Bar - Mobile */}
      {!hideBottomNav && (
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white shadow-lg z-50">
          <div className="grid grid-cols-4 h-16">
            <Link
              to="/"
              className={`flex flex-col items-center justify-center ${
                isActive('/') 
                  ? 'bg-gray-100 text-blue-600' 
                  : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
              }`}
            >
              <LayoutDashboard className="h-6 w-6" />
              <span className="text-xs mt-1">Dashboard</span>
            </Link>
            <Link
              to="/search-visit"
              className={`flex flex-col items-center justify-center ${
                isActive('/search-visit') 
                  ? 'bg-gray-100 text-blue-600' 
                  : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
              }`}
            >
              <Search className="h-6 w-6" />
              <span className="text-xs mt-1">Search</span>
            </Link>
            <Link
              to="/manage"
              className={`flex flex-col items-center justify-center ${
                isActive('/manage') 
                  ? 'bg-gray-100 text-blue-600' 
                  : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
              }`}
            >
              <Settings className="h-6 w-6" />
              <span className="text-xs mt-1">Manage</span>
            </Link>
            <Link
              to="/add-visit"
              className="flex flex-col items-center justify-center bg-blue-600 text-white"
            >
              <Plus className="h-6 w-6" />
              <span className="text-xs mt-1">Add Visit</span>
            </Link>
          </div>
        </nav>
      )}

      {/* Desktop Navigation */}
      <nav className="hidden lg:block bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            {/* Left side - Logo */}
            <div className="flex items-center space-x-6">
              <Link to="/" className="flex items-center space-x-2">
                <Wrench className="h-6 w-6 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">Sp1nMate</span>
              </Link>
            </div>

            {/* Center - Main Navigation */}
            <div className="flex items-center justify-center flex-1 space-x-4">
              <Link
                to="/"
                className={`flex items-center space-x-1 px-3 py-2 rounded-md ${
                  isActive('/') 
                    ? 'bg-gray-100 text-blue-600' 
                    : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                }`}
              >
                <LayoutDashboard className="h-5 w-5" />
                <span>Dashboard</span>
              </Link>
              <Link
                to="/search-visit"
                className={`flex items-center space-x-1 px-3 py-2 rounded-md ${
                  isActive('/search-visit') 
                    ? 'bg-gray-100 text-blue-600' 
                    : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                }`}
              >
                <Search className="h-5 w-5" />
                <span>Search Visit</span>
              </Link>
              <Link
                to="/manage"
                className={`flex items-center space-x-1 px-3 py-2 rounded-md ${
                  isActive('/manage') 
                    ? 'bg-gray-100 text-blue-600' 
                    : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                }`}
              >
                <Settings className="h-5 w-5" />
                <span>Manage</span>
              </Link>
              <Link
                to="/add-visit"
                className="flex items-center space-x-1 px-3 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors"
              >
                <Plus className="h-5 w-5" />
                <span>Add Visit</span>
              </Link>
            </div>

            {/* Right side - User Menu */}
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center justify-center h-10 w-10 rounded-full hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <UserCircle className="h-6 w-6 text-gray-700" />
                </button>

                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 ring-1 ring-black ring-opacity-5">
                    <Link
                      to="/settings"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={() => setIsUserMenuOpen(false)}
                    >
                      Settings
                    </Link>
                    <button
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={() => {
                        setIsUserMenuOpen(false)
                        // Add logout logic here
                      }}
                    >
                      Sign out
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </nav>
    </>
  )
}