import type { CustomerInfo, ServiceSubject, PredefinedServicePart, PredefinedService, Label, Mechanic, Visit } from './types';

export const customerInfos: CustomerInfo[] = [
  { email: "daniel@test.com", id: "1", name: "Daniel", phoneNumber: "777339223" },
  { email: "czeslaw@test.com", id: "2", name: "Czeslaw", phoneNumber: "792392322" },
  { email: "andrzej@test.com", id: "3", name: "Andrzej", phoneNumber: "606505404" },
  { email: "krystian@test.com", id: "4", name: "Krystian", phoneNumber: "505404303" },
];

export const serviceSubjects: ServiceSubject[] = [
  { id: "456", name: "Romet", notes: "romet notes", photoIds: [] },
  { id: "123", name: "Gravel", notes: "gravel notes", photoIds: [] },
  { id: "222", name: "Merida", notes: "merida notes", photoIds: [] },
  { id: "333", name: "Kross", notes: "kross notes", photoIds: [] },
  { id: "444", name: "Scott", notes: "scott notes", photoIds: [] },
];

export const predefinedServiceParts: PredefinedServicePart[] = [
  { id: "1", name: "Chain", price: 10, amount: 5 },
  { id: "2", name: "Brake Pads", price: 15, amount: 5 },
  { id: "3", name: "Tire", price: 25, amount: 5 },
  { id: "4", name: "Tube", price: 8, amount: 5 },
  { id: "5", name: "Handlebar Grip", price: 12, amount: 5 },
];

export const predefinedServices: PredefinedService[] = [
  { id: "1", name: "Change chain", price: 20 },
  { id: "2", name: "Adjust brakes", price: 15 },
  { id: "3", name: "Replace tire", price: 30 },
  { id: "4", name: "Tune up", price: 40 },
];

export const labels: Label[] = [
  { id: "1", name: "No Status", color: "#ef4444" },
  { id: "2", name: "Waiting for intake", color: "#f97316" },
  { id: "3", name: "Todo", color: "#9333ea" },
  { id: "4", name: "InProgress", color: "#3b82f6" },
  { id: "5", name: "Released", color: "#16a34a" },
];

export const mechanics: Mechanic[] = [
  { id: "1", name: "Marcin", email: "marcin@spinmate.com" },
  { id: "2", name: "Dawid", email: "dawid@spinmate.com" },
  { id: "3", name: "Łukasz", email: "lukasz@spinmate.com" },
  { id: "4", name: "Mariusz", email: "mariusz@spinmate.com" },
];

// Get today's date and create dates for the next few days
const today = new Date();
const tomorrow = new Date(today);
tomorrow.setDate(tomorrow.getDate() + 1);
const dayAfterTomorrow = new Date(today);
dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 2);

// Create dates for the past
const yesterday = new Date(today);
yesterday.setDate(yesterday.getDate() - 1);
const twoDaysAgo = new Date(today);
twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
const threeDaysAgo = new Date(today);
threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
const fourDaysAgo = new Date(today);
fourDaysAgo.setDate(fourDaysAgo.getDate() - 4);
const fiveDaysAgo = new Date(today);
fiveDaysAgo.setDate(fiveDaysAgo.getDate() - 5);

// Format dates to ISO string and take only the date part
const todayStr = today.toISOString().split('T')[0];
const tomorrowStr = tomorrow.toISOString().split('T')[0];
const dayAfterTomorrowStr = dayAfterTomorrow.toISOString().split('T')[0];
const yesterdayStr = yesterday.toISOString().split('T')[0];
const twoDaysAgoStr = twoDaysAgo.toISOString().split('T')[0];
const threeDaysAgoStr = threeDaysAgo.toISOString().split('T')[0];
const fourDaysAgoStr = fourDaysAgo.toISOString().split('T')[0];
const fiveDaysAgoStr = fiveDaysAgo.toISOString().split('T')[0];

// Create a date 2 hours ago for SMS sent timestamp
const twoHoursAgo = new Date(today);
twoHoursAgo.setHours(twoHoursAgo.getHours() - 2);

// Customer names for variety
const customerNames = [
  "John Smith", "Emma Davis", "Michael Johnson", "Sarah Wilson", "David Brown",
  "Lisa Anderson", "Robert Taylor", "Jennifer Martinez", "William Garcia", "Ashley Rodriguez",
  "Christopher Lee", "Amanda Walker", "Matthew Hall", "Jessica Allen", "Daniel Young",
  "Michelle King", "Anthony Wright", "Stephanie Lopez", "Mark Hill", "Nicole Scott",
  "Steven Green", "Rachel Adams", "Kevin Baker", "Laura Gonzalez", "Brian Nelson",
  "Kimberly Carter", "Edward Mitchell", "Donna Perez", "Ronald Roberts", "Carol Turner"
];

// Service objects for variety
const serviceObjects = [
  "Mountain Bike", "Road Bike", "BMX", "City Bike", "Hybrid Bike", "Electric Bike",
  "Gravel Bike", "Touring Bike", "Folding Bike", "Kids Bike", "Cruiser Bike",
  "Fat Bike", "Cyclocross Bike", "Track Bike", "Recumbent Bike", "Tandem Bike",
  "Cargo Bike", "Commuter Bike", "Vintage Bike", "Racing Bike"
];

// Phone numbers for variety
const phoneNumbers = [
  "123-456-789", "234-567-890", "345-678-901", "456-789-012", "567-890-123",
  "678-901-234", "789-012-345", "890-123-456", "901-234-567", "012-345-678",
  "111-222-333", "222-333-444", "333-444-555", "444-555-666", "555-666-777",
  "666-777-888", "777-888-999", "888-999-000", "999-000-111", "000-111-222"
];

// Email domains for variety
const emailDomains = ["@example.com", "@gmail.com", "@yahoo.com", "@hotmail.com", "@outlook.com"];

export const visits: Visit[] = [
  // Original visits
  {
    id: "1",
    customerName: "John Smith",
    serviceObject: "Mountain Bike",
    phoneNumber: "123-456-789",
    email: "john@example.com",
    intakeDate: todayStr,
    releaseDate: tomorrowStr,
    status: "2",
    mechanic: "1",
    services: [{ name: "Tune up", price: 40 }],
    parts: [{ name: "Chain", price: 10 }],
    notes: "Regular maintenance",
    recommendations: "Consider replacing brake pads within the next 2-3 months. Front tire shows signs of wear.",
    totalCost: 50,
    smsSent: {
      confirmation: {
        date: twoHoursAgo.toISOString(),
        message: "Dear John Smith, we've received your Mountain Bike for service. Your visit ID is #1."
      }
    }
  },
  {
    id: "2",
    customerName: "Emma Davis",
    serviceObject: "Road Bike",
    phoneNumber: "234-567-890",
    email: "emma@example.com",
    intakeDate: todayStr,
    releaseDate: dayAfterTomorrowStr,
    status: "3",
    mechanic: "2",
    services: [{ name: "Replace tire", price: 30 }],
    parts: [{ name: "Tire", price: 25 }],
    notes: "Flat tire replacement",
    totalCost: 55
  },
  {
    id: "3",
    customerName: "Michael Johnson",
    serviceObject: "BMX",
    phoneNumber: "345-678-901",
    email: "michael@example.com",
    intakeDate: tomorrowStr,
    releaseDate: dayAfterTomorrowStr,
    status: "1",
    mechanic: "3",
    services: [{ name: "Adjust brakes", price: 15 }],
    parts: [{ name: "Brake Pads", price: 15 }],
    notes: "Brake adjustment",
    totalCost: 30
  },
  {
    id: "4",
    customerName: "Sarah Wilson",
    serviceObject: "City Bike",
    phoneNumber: "456-789-012",
    email: "sarah@example.com",
    intakeDate: todayStr,
    releaseDate: tomorrowStr,
    status: "5",
    mechanic: "4",
    services: [{ name: "Change chain", price: 20 }],
    parts: [{ name: "Chain", price: 10 }],
    notes: "Chain replacement",
    totalCost: 30
  },
  {
    id: "5",
    customerName: "David Brown",
    serviceObject: "Hybrid Bike",
    phoneNumber: "567-890-123",
    email: "david@example.com",
    intakeDate: dayAfterTomorrowStr,
    releaseDate: dayAfterTomorrowStr,
    status: "2",
    mechanic: "1",
    services: [{ name: "Tune up", price: 40 }],
    parts: [{ name: "Handlebar Grip", price: 12 }],
    notes: "General maintenance",
    totalCost: 52
  },
  {
    id: "6",
    customerName: "Lisa Anderson",
    serviceObject: "Electric Bike",
    phoneNumber: "678-901-234",
    email: "lisa@example.com",
    intakeDate: tomorrowStr,
    releaseDate: dayAfterTomorrowStr,
    status: "3",
    mechanic: "2",
    services: [{ name: "Adjust brakes", price: 15 }],
    parts: [{ name: "Brake Pads", price: 15 }],
    notes: "Brake maintenance",
    totalCost: 30
  },
  // 30 additional visits with "Released" status
  ...Array.from({ length: 30 }, (_, index) => {
    const visitId = (7 + index).toString();
    const customerIndex = index % customerNames.length;
    const serviceIndex = index % serviceObjects.length;
    const phoneIndex = index % phoneNumbers.length;
    const mechanicIndex = index % mechanics.length;
    const emailDomainIndex = index % emailDomains.length;
    
    // Vary the dates for released visits
    const intakeDates = [fiveDaysAgoStr, fourDaysAgoStr, threeDaysAgoStr, twoDaysAgoStr, yesterdayStr];
    const releaseDates = [fourDaysAgoStr, threeDaysAgoStr, twoDaysAgoStr, yesterdayStr, todayStr];
    const dateIndex = index % intakeDates.length;
    
    const customerName = customerNames[customerIndex];
    const firstName = customerName.split(' ')[0].toLowerCase();
    
    return {
      id: visitId,
      customerName: customerName,
      serviceObject: serviceObjects[serviceIndex],
      phoneNumber: phoneNumbers[phoneIndex],
      email: `${firstName}${emailDomains[emailDomainIndex]}`,
      intakeDate: intakeDates[dateIndex],
      releaseDate: releaseDates[dateIndex],
      status: "5", // Released status
      mechanic: mechanics[mechanicIndex].id,
      services: [{ name: "Complete service", price: 35 + (index % 20) }],
      parts: [{ name: "Various parts", price: 15 + (index % 15) }],
      notes: `Service completed for ${serviceObjects[serviceIndex]}`,
      recommendations: index % 3 === 0 ? "Regular maintenance recommended in 6 months" : undefined,
      totalCost: 50 + (index % 30),
    };
  })
];

// Utility functions for finding items by ID
export const findCustomerById = (id: string) => customerInfos.find(customer => customer.id === id);
export const findServiceSubjectById = (id: string) => serviceSubjects.find(subject => subject.id === id);
export const findPredefinedServicePartById = (id: string) => predefinedServiceParts.find(part => part.id === id);
export const findPredefinedServiceById = (id: string) => predefinedServices.find(service => service.id === id);
export const findLabelById = (id: string) => labels.find(label => label.id === id);
export const findMechanicById = (id: string) => mechanics.find(mechanic => mechanic.id === id);
export const findVisitById = (id: string) => visits.find(visit => visit.id === id);