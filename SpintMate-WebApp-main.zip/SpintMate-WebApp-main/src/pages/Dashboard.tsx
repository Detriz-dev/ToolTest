import React from 'react'
import { visits, labels } from '../data/constants'
import { useNavigate } from 'react-router-dom'

export function Dashboard() {
  const navigate = useNavigate()

  // Get today's date at midnight for comparison
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  // Filter visits for today's intakes
  const todayIntakes = visits.filter(visit => {
    const intakeDate = new Date(visit.intakeDate)
    intakeDate.setHours(0, 0, 0, 0)
    return intakeDate.getTime() === today.getTime()
  })

  // Filter visits for today's releases
  const todayReleases = visits.filter(visit => {
    const releaseDate = new Date(visit.releaseDate)
    releaseDate.setHours(0, 0, 0, 0)
    return releaseDate.getTime() === today.getTime()
  })

  // Get statistics - exclude released visits from total count
  const activeVisits = visits.filter(visit => {
    const status = labels.find(label => label.id === visit.status)
    return status?.name !== 'Released'
  })
  const totalActiveVisits = activeVisits.length
  const todayIntakeCount = todayIntakes.length
  const todayReleaseCount = todayReleases.length

  // Get visit counts by label - exclude "Released" status
  const activeLabels = labels.filter(label => label.name !== 'Released')
  const visitsByLabel = activeLabels.map(label => ({
    ...label,
    count: visits.filter(visit => visit.status === label.id).length
  }))

  // Helper function to navigate to all visits with filters
  const navigateToAllVisitsWithFilters = (filters: Record<string, string>) => {
    const searchParams = new URLSearchParams()
    
    Object.entries(filters).forEach(([key, value]) => {
      if (value) {
        searchParams.set(key, value)
      }
    })
    
    const queryString = searchParams.toString()
    navigate(`/all-visits${queryString ? `?${queryString}` : ''}`)
  }

  // Navigate to all visits with all active statuses selected (excluding Released)
  const navigateToAllVisits = () => {
    const statusIds = activeLabels.map(label => label.id).join(',')
    navigate(`/all-visits?status=${statusIds}`)
  }

  // Navigate to all visits with all statuses except "Released" selected
  const navigateToTotalVisits = () => {
    const nonReleasedLabels = labels.filter(label => label.name !== 'Released')
    const statusIds = nonReleasedLabels.map(label => label.id).join(',')
    navigate(`/all-visits?status=${statusIds}`)
  }

  // Format today's date for URL parameters
  const todayString = today.toISOString().split('T')[0]

  // Navigate to all visits showing only today's releases
  const navigateToTodayReleases = () => {
    navigate(`/all-visits?releaseDate=${todayString}`)
  }

  return (
    <div className="space-y-6 -mx-4 sm:mx-0">
      {/* Visit Labels */}
      <div className="bg-white rounded-none sm:rounded-lg shadow-sm overflow-hidden">
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 px-4 sm:px-0">Visit Status Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 px-4 sm:px-0">
            {/* All active visits card */}
            <div
              className="p-4 rounded-lg cursor-pointer hover:shadow-md transition-shadow bg-gray-50 border-2 border-gray-200"
              onClick={navigateToAllVisits}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-gray-400" />
                  <span className="font-medium text-gray-900">Active visits</span>
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  {totalActiveVisits}
                </span>
              </div>
            </div>
            
            {visitsByLabel.map((label) => (
              <div
                key={label.id}
                className="p-4 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                style={{ backgroundColor: `${label.color}10` }}
                onClick={() => navigateToAllVisitsWithFilters({ status: label.id })}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: label.color }}
                    />
                    <span className="font-medium text-gray-900">
                      {label.name}
                    </span>
                  </div>
                  <span className="text-2xl font-bold text-gray-900">
                    {label.count}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}