import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, Filter, X } from 'lucide-react'
import { visits, findLabelById, findMechanicById, labels, mechanics } from '../data/constants'

export function TotalVisits() {
  const navigate = useNavigate()
  const [searchQuery, setSearchQuery] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [statusFilters, setStatusFilters] = useState<string[]>([])
  const [mechanicFilter, setMechanicFilter] = useState<string>('')
  const [intakeDateStart, setIntakeDateStart] = useState('')
  const [intakeDateEnd, setIntakeDateEnd] = useState('')
  const [releaseDateStart, setReleaseDateStart] = useState('')
  const [releaseDateEnd, setReleaseDateEnd] = useState('')

  const filteredVisits = visits.filter(visit => {
    const matchesSearch = 
      visit.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      visit.serviceObject.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilters.length === 0 || statusFilters.includes(visit.status)
    const matchesMechanic = !mechanicFilter || visit.mechanic === mechanicFilter

    const releaseDate = new Date(visit.releaseDate)

    const matchesReleaseDate = (!releaseDateStart || releaseDate >= new Date(releaseDateStart)) &&
                              (!releaseDateEnd || releaseDate <= new Date(releaseDateEnd))

    return matchesSearch && matchesStatus && matchesMechanic && matchesReleaseDate
  })

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const getStatusColor = (statusId: string) => {
    const status = findLabelById(statusId)
    return status?.color || '#gray-500'
  }

  const toggleStatusFilter = (statusId: string) => {
    setStatusFilters(prev => {
      if (prev.includes(statusId)) {
        return prev.filter(id => id !== statusId)
      } else {
        return [...prev, statusId]
      }
    })
  }

  const clearAllFilters = () => {
    setStatusFilters([])
  }

  const isStatusSelected = (statusId: string) => {
    return statusFilters.includes(statusId)
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Total Visits</h1>

      <div className="flex flex-col space-y-4">
        <div className="flex items-center space-x-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search visits..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="p-2 border rounded-lg hover:bg-gray-50"
          >
            <Filter className="h-5 w-5 text-gray-600" />
          </button>
        </div>

        {/* Status Badges */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-700">Filter by Status:</span>
            {statusFilters.length > 0 && (
              <button
                onClick={clearAllFilters}
                className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
              >
                <X className="h-4 w-4 mr-1" />
                Clear all
              </button>
            )}
          </div>
          <div className="overflow-x-auto pb-2">
            <div className="flex space-x-2 min-w-min">
              {labels.map(label => (
                <button
                  key={label.id}
                  onClick={() => toggleStatusFilter(label.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors border-2`}
                  style={{
                    backgroundColor: isStatusSelected(label.id) ? label.color : 'transparent',
                    color: isStatusSelected(label.id) ? 'white' : label.color,
                    borderColor: label.color
                  }}
                >
                  {label.name}
                  {isStatusSelected(label.id) && (
                    <span className="ml-2 text-xs">✓</span>
                  )}
                </button>
              ))}
            </div>
          </div>
          {statusFilters.length > 0 && (
            <div className="text-sm text-gray-600">
              Showing visits with status: {statusFilters.map(id => findLabelById(id)?.name).join(', ')}
            </div>
          )}
        </div>
      </div>

      {showFilters && (
        <div className="bg-white rounded-lg shadow-sm p-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mechanic</label>
            <select
              value={mechanicFilter}
              onChange={(e) => setMechanicFilter(e.target.value)}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Mechanics</option>
              {mechanics.map(mechanic => (
                <option key={mechanic.id} value={mechanic.id}>{mechanic.name}</option>
              ))}
            </select>
          </div>
          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-700">Release Date</label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <input
                  type="date"
                  value={releaseDateStart}
                  onChange={(e) => setReleaseDateStart(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="From"
                />
              </div>
              <div>
                <input
                  type="date"
                  value={releaseDateEnd}
                  onChange={(e) => setReleaseDateEnd(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="To"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {filteredVisits.map((visit) => (
          <div
            key={visit.id}
            onClick={() => navigate(`/customer-visit/${visit.id}`)}
            className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{visit.serviceObject}</h3>
                <p className="text-gray-600 mt-1">{visit.customerName}</p>
              </div>
              <div className="flex flex-col items-end space-y-2">
                <span
                  className="px-2 py-1 rounded-full text-sm font-medium"
                  style={{
                    backgroundColor: `${getStatusColor(visit.status)}20`,
                    color: getStatusColor(visit.status)
                  }}
                >
                  {findLabelById(visit.status)?.name}
                </span>
                <div className="text-sm text-gray-500">
                  <p>Mechanic: {findMechanicById(visit.mechanic)?.name}</p>
                  <p>Release: {formatDate(visit.releaseDate)}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
        {filteredVisits.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <p className="text-gray-500">No visits found</p>
          </div>
        )}
      </div>
    </div>
  )
}