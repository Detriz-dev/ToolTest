import React, { useState } from 'react'
import { Plus, Edit2, Trash2, X, MoreVertical, Mail } from 'lucide-react'
import { mechanics } from '../data/constants'
import { Toast } from '../components/ui/Toast'
import { useToast } from '../hooks/useToast'

export function Mechanics() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedMechanic, setSelectedMechanic] = useState<typeof mechanics[0] | null>(null)
  const [mechanicsList, setMechanicsList] = useState(mechanics)
  const [activeMenu, setActiveMenu] = useState<string | null>(null)
  const { toast, showToast, hideToast } = useToast()

  const handleDelete = (id: string) => {
    setMechanicsList(prev => prev.filter(m => m.id !== id))
    setActiveMenu(null)
    showToast('Successfully deleted!')
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const form = e.target as HTMLFormElement
    const formData = new FormData(form)
    const name = formData.get('name') as string
    const email = formData.get('email') as string

    if (selectedMechanic) {
      setMechanicsList(prev => 
        prev.map(m => m.id === selectedMechanic.id ? { ...m, name, email } : m)
      )
      showToast('Successfully saved!')
    } else {
      const newMechanic = {
        id: String(Date.now()),
        name,
        email
      }
      setMechanicsList(prev => [...prev, newMechanic])
      showToast('Successfully added!')
    }
    setIsModalOpen(false)
    setSelectedMechanic(null)
  }

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Mechanics</h1>
          <button
            onClick={() => {
              setSelectedMechanic(null)
              setIsModalOpen(true)
            }}
            className="flex items-center px-4 py-2 border border-blue-600 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add
          </button>
        </div>

        <div className="space-y-4">
          {mechanicsList.map((mechanic) => (
            <div
              key={mechanic.id}
              className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <h3 className="text-lg font-semibold text-gray-900">{mechanic.name}</h3>
                  {mechanic.email && (
                    <div className="flex items-center text-gray-600">
                      <Mail className="h-4 w-4 mr-2" />
                      <span>{mechanic.email}</span>
                    </div>
                  )}
                </div>
                <div className="relative">
                  {/* Mobile menu button */}
                  <button
                    onClick={() => setActiveMenu(activeMenu === mechanic.id ? null : mechanic.id)}
                    className="lg:hidden p-2 text-gray-600 hover:text-gray-900 rounded-full hover:bg-gray-100"
                  >
                    <MoreVertical className="h-5 w-5" />
                  </button>
                  {/* Desktop buttons */}
                  <div className="hidden lg:flex lg:space-x-2">
                    <button
                      onClick={() => {
                        setSelectedMechanic(mechanic)
                        setIsModalOpen(true)
                      }}
                      className="p-2 text-gray-600 hover:text-blue-600 rounded-full hover:bg-gray-100"
                    >
                      <Edit2 className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(mechanic.id)}
                      className="p-2 text-gray-600 hover:text-red-600 rounded-full hover:bg-gray-100"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                  {/* Mobile menu */}
                  {activeMenu === mechanic.id && (
                    <div className="lg:hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 ring-1 ring-black ring-opacity-5 z-10">
                      <button
                        onClick={() => {
                          setSelectedMechanic(mechanic)
                          setIsModalOpen(true)
                          setActiveMenu(null)
                        }}
                        className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        <Edit2 className="h-4 w-4 mr-2" />
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(mechanic.id)}
                        className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {isModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">
                  {selectedMechanic ? 'Edit Mechanic' : 'Add New Mechanic'}
                </h2>
                <button
                  onClick={() => {
                    setIsModalOpen(false)
                    setSelectedMechanic(null)
                  }}
                  className="p-1 hover:bg-gray-100 rounded-full"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Name
                  </label>
                  <input
                    name="name"
                    type="text"
                    defaultValue={selectedMechanic?.name}
                    required
                    className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email (optional)
                  </label>
                  <input
                    name="email"
                    type="email"
                    defaultValue={selectedMechanic?.email}
                    className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => {
                      setIsModalOpen(false)
                      setSelectedMechanic(null)
                    }}
                    className="px-4 py-2 border rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    {selectedMechanic ? 'Save Changes' : 'Add Mechanic'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  )
}