import React from 'react'
import { visits, mechanics, labels } from '../data/constants'
import { BarChart3, TrendingUp, Users, Clock, DollarSign, Calendar, ArrowUp, ArrowDown } from 'lucide-react'

export function Stats() {
  // Calculate revenue metrics
  const totalRevenue = visits.reduce((sum, visit) => sum + visit.totalCost, 0)
  const averageTicket = totalRevenue / visits.length
  
  // Calculate visit metrics
  const today = new Date()
  const thisMonth = today.getMonth()
  const thisYear = today.getFullYear()
  
  const visitsThisMonth = visits.filter(visit => {
    const visitDate = new Date(visit.intakeDate)
    return visitDate.getMonth() === thisMonth && visitDate.getFullYear() === thisYear
  })
  
  const revenueThisMonth = visitsThisMonth.reduce((sum, visit) => sum + visit.totalCost, 0)
  
  // Calculate mechanic performance
  const mechanicPerformance = mechanics.map(mechanic => {
    const mechanicVisits = visits.filter(visit => visit.mechanic === mechanic.id)
    const totalRevenue = mechanicVisits.reduce((sum, visit) => sum + visit.totalCost, 0)
    const averageRevenue = mechanicVisits.length ? totalRevenue / mechanicVisits.length : 0
    
    return {
      ...mechanic,
      totalVisits: mechanicVisits.length,
      totalRevenue,
      averageRevenue
    }
  }).sort((a, b) => b.totalRevenue - a.totalRevenue)

  // Calculate service status distribution
  const statusDistribution = labels.map(label => {
    const count = visits.filter(visit => visit.status === label.id).length
    const percentage = (count / visits.length) * 100
    
    return {
      ...label,
      count,
      percentage
    }
  })

  // Calculate month-over-month growth
  const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1)
  const visitsLastMonth = visits.filter(visit => {
    const visitDate = new Date(visit.intakeDate)
    return visitDate.getMonth() === lastMonth.getMonth() && visitDate.getFullYear() === lastMonth.getFullYear()
  })
  
  const revenueLastMonth = visitsLastMonth.reduce((sum, visit) => sum + visit.totalCost, 0)
  const revenueGrowth = ((revenueThisMonth - revenueLastMonth) / revenueLastMonth) * 100

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Business Statistics</h1>
      
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">${totalRevenue.toFixed(2)}</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <DollarSign className="h-6 w-6 text-blue-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <span className={`flex items-center text-sm ${revenueGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {revenueGrowth >= 0 ? <ArrowUp className="h-4 w-4 mr-1" /> : <ArrowDown className="h-4 w-4 mr-1" />}
              {Math.abs(revenueGrowth).toFixed(1)}%
            </span>
            <span className="text-sm text-gray-500 ml-2">vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Average Ticket</p>
              <p className="text-2xl font-bold text-gray-900">${averageTicket.toFixed(2)}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <BarChart3 className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-sm text-gray-500">
              Based on {visits.length} total visits
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Monthly Visits</p>
              <p className="text-2xl font-bold text-gray-900">{visitsThisMonth.length}</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <Calendar className="h-6 w-6 text-purple-600" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-sm text-gray-500">
              This month's activity
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Mechanics</p>
              <p className="text-2xl font-bold text-gray-900">{mechanics.length}</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-lg">
              <Users className="h-6 w-6 text-orange-600" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-sm text-gray-500">
              Team capacity
            </div>
          </div>
        </div>
      </div>

      {/* Mechanic Performance */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Mechanic Performance</h2>
        <div className="space-y-4">
          {mechanicPerformance.map((mechanic) => (
            <div key={mechanic.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="p-2 bg-gray-100 rounded-lg">
                  <Users className="h-5 w-5 text-gray-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">{mechanic.name}</p>
                  <p className="text-sm text-gray-500">{mechanic.totalVisits} visits</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-gray-900">${mechanic.totalRevenue.toFixed(2)}</p>
                <p className="text-sm text-gray-500">
                  Avg: ${mechanic.averageRevenue.toFixed(2)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Status Distribution */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Service Status Distribution</h2>
        <div className="space-y-4">
          {statusDistribution.map((status) => (
            <div key={status.id}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700">{status.name}</span>
                <span className="text-sm font-medium text-gray-700">{status.count} visits</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="h-2.5 rounded-full"
                  style={{
                    width: `${status.percentage}%`,
                    backgroundColor: status.color
                  }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Business Insights */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Business Insights</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-green-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <h3 className="font-medium text-green-900">Revenue Growth</h3>
            </div>
            <p className="mt-2 text-sm text-green-800">
              Monthly revenue is {revenueGrowth >= 0 ? 'up' : 'down'} by {Math.abs(revenueGrowth).toFixed(1)}% 
              compared to last month, with a total of ${revenueThisMonth.toFixed(2)}.
            </p>
          </div>
          
          <div className="p-4 bg-blue-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Clock className="h-5 w-5 text-blue-600" />
              <h3 className="font-medium text-blue-900">Service Efficiency</h3>
            </div>
            <p className="mt-2 text-sm text-blue-800">
              Average of {(visitsThisMonth.length / mechanics.length).toFixed(1)} visits per mechanic this month,
              with a total workload of {visitsThisMonth.length} visits.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}