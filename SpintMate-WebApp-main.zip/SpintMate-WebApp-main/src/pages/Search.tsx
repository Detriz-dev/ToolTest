import React, { useState, useEffect, useRef } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { Search as SearchIcon, Filter, X, Calendar, User } from 'lucide-react'
import { visits, findLabelById, findMechanicById, labels, mechanics } from '../data/constants'

export function AllVisits() {
  const navigate = useNavigate()
  const location = useLocation()
  const searchInputRef = useRef<HTMLInputElement>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilters, setStatusFilters] = useState<string[]>([])
  const [mechanicFilter, setMechanicFilter] = useState<string>('')
  const [releaseDate, setReleaseDate] = useState('')
  const [intakeDate, setIntakeDate] = useState('')
  const [showFilters, setShowFilters] = useState(false)

  // Filter out "Released" status from available labels for UI
  const activeLabels = labels.filter(label => label.name !== 'Released')

  // Auto-focus search input on mobile when component mounts
  useEffect(() => {
    const isMobile = window.innerWidth <= 768
    if (isMobile && searchInputRef.current) {
      // Small delay to ensure the component is fully rendered
      setTimeout(() => {
        searchInputRef.current?.focus()
      }, 100)
    }
  }, [])

  // Parse URL parameters on component mount
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search)
    
    // Parse search query
    const query = searchParams.get('q')
    if (query) {
      setSearchQuery(query)
    }

    // Parse status filters (comma-separated) - allow all labels including Released
    const statusParam = searchParams.get('status')
    if (statusParam) {
      const statusIds = statusParam.split(',').filter(id => 
        labels.some(label => label.id === id)
      )
      setStatusFilters(statusIds)
    }

    // Parse mechanic filter
    const mechanicParam = searchParams.get('mechanic')
    if (mechanicParam && mechanics.some(m => m.id === mechanicParam)) {
      setMechanicFilter(mechanicParam)
    }

    // Parse release date
    const releaseDateParam = searchParams.get('releaseDate')
    if (releaseDateParam) {
      setReleaseDate(releaseDateParam)
    }

    // Parse intake date
    const intakeDateParam = searchParams.get('intakeDate')
    if (intakeDateParam) {
      setIntakeDate(intakeDateParam)
    }
  }, [location.search])

  // Update URL when filters change
  useEffect(() => {
    const searchParams = new URLSearchParams()

    // Add search query
    if (searchQuery) {
      searchParams.set('q', searchQuery)
    }

    // Add status filters
    if (statusFilters.length > 0) {
      searchParams.set('status', statusFilters.join(','))
    }

    // Add mechanic filter
    if (mechanicFilter) {
      searchParams.set('mechanic', mechanicFilter)
    }

    // Add release date
    if (releaseDate) {
      searchParams.set('releaseDate', releaseDate)
    }

    // Add intake date
    if (intakeDate) {
      searchParams.set('intakeDate', intakeDate)
    }

    // Update URL without triggering navigation
    const newSearch = searchParams.toString()
    const newUrl = newSearch ? `${location.pathname}?${newSearch}` : location.pathname
    
    if (newUrl !== `${location.pathname}${location.search}`) {
      navigate(newUrl, { replace: true })
    }
  }, [searchQuery, statusFilters, mechanicFilter, releaseDate, intakeDate, navigate, location.pathname, location.search])

  // Filter visits - include released visits when searching or when explicitly filtered
  const filteredVisits = visits.filter(visit => {
    const matchesSearch = 
      visit.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      visit.serviceObject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      visit.phoneNumber.includes(searchQuery) // Added phone number search

    const matchesStatus = statusFilters.length === 0 || statusFilters.includes(visit.status)
    const matchesMechanic = !mechanicFilter || visit.mechanic === mechanicFilter

    const visitReleaseDate = new Date(visit.releaseDate)
    const visitIntakeDate = new Date(visit.intakeDate)

    const matchesReleaseDate = !releaseDate || visitReleaseDate.toDateString() === new Date(releaseDate).toDateString()
    const matchesIntakeDate = !intakeDate || visitIntakeDate.toDateString() === new Date(intakeDate).toDateString()

    // Check if visit is released
    const visitStatus = findLabelById(visit.status)
    const isReleasedVisit = visitStatus?.name === 'Released'
    
    // Include released visits if:
    // 1. User is actively searching (has search query)
    // 2. User has explicitly selected Released status in filters
    // 3. User has applied date filters (might be looking for specific released visits)
    // 4. User has applied mechanic filters
    const hasActiveSearch = searchQuery.trim().length > 0
    const hasReleasedInFilters = statusFilters.some(statusId => {
      const status = findLabelById(statusId)
      return status?.name === 'Released'
    })
    const hasDateFilters = releaseDate || intakeDate
    const hasMechanicFilter = mechanicFilter

    const shouldIncludeReleased = hasActiveSearch || hasReleasedInFilters || hasDateFilters || hasMechanicFilter

    // If no filters are applied, exclude released visits by default
    // If any filters are applied, include released visits based on the conditions above
    const shouldIncludeVisit = statusFilters.length === 0 && !hasActiveSearch && !hasDateFilters && !hasMechanicFilter 
      ? !isReleasedVisit 
      : (isReleasedVisit ? shouldIncludeReleased : true)

    return matchesSearch && matchesStatus && matchesMechanic && matchesReleaseDate && matchesIntakeDate && shouldIncludeVisit
  }).sort((a, b) => {
    // Sort by status: Released first, then others
    const aStatus = findLabelById(a.status)
    const bStatus = findLabelById(b.status)
    
    const aIsReleased = aStatus?.name === 'Released'
    const bIsReleased = bStatus?.name === 'Released'
    
    if (aIsReleased && !bIsReleased) return -1
    if (!aIsReleased && bIsReleased) return 1
    
    // If both have same release status, sort by date (newest first)
    return new Date(b.intakeDate).getTime() - new Date(a.intakeDate).getTime()
  })

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const getStatusColor = (statusId: string) => {
    const status = findLabelById(statusId)
    return status?.color || '#gray-500'
  }

  const toggleStatusFilter = (statusId: string) => {
    setStatusFilters(prev => {
      if (prev.includes(statusId)) {
        return prev.filter(id => id !== statusId)
      } else {
        return [...prev, statusId]
      }
    })
  }

  const clearAllStatusFilters = () => {
    setStatusFilters([])
  }

  const clearAllFilters = () => {
    setStatusFilters([])
    setMechanicFilter('')
    setReleaseDate('')
    setIntakeDate('')
    setSearchQuery('')
  }

  const isStatusSelected = (statusId: string) => {
    return statusFilters.includes(statusId)
  }

  const hasActiveFilters = () => {
    return statusFilters.length > 0 || 
           mechanicFilter !== '' || 
           releaseDate !== '' || 
           intakeDate !== '' ||
           searchQuery !== ''
  }

  // Check if specific filters (mechanic, intake date, release date, search) are active
  const hasActiveSpecificFilters = () => {
    return mechanicFilter !== '' || 
           releaseDate !== '' || 
           intakeDate !== '' ||
           searchQuery !== ''
  }

  // Select all active statuses (excluding Released from UI)
  const selectAllStatuses = () => {
    setStatusFilters(activeLabels.map(label => label.id))
  }

  // Check if released visits are being shown
  const showingReleasedVisits = () => {
    return filteredVisits.some(visit => {
      const status = findLabelById(visit.status)
      return status?.name === 'Released'
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-4">
        {/* Status Labels with Filter Button */}
        <div className="flex-1">
          <div className="flex flex-wrap gap-2 items-center">
            {/* All Status Button */}
            <button
              onClick={() => statusFilters.length === activeLabels.length ? clearAllStatusFilters() : selectAllStatuses()}
              className={`px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors border-2 ${
                statusFilters.length === activeLabels.length
                  ? 'bg-gray-600 text-white border-gray-600'
                  : 'bg-transparent text-gray-600 border-gray-400 hover:bg-gray-50'
              }`}
            >
              All Active
              {statusFilters.length === activeLabels.length && (
                <span className="ml-1 text-xs">✓</span>
              )}
            </button>
            
            {activeLabels.map(label => (
              <button
                key={label.id}
                onClick={() => toggleStatusFilter(label.id)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors border-2`}
                style={{
                  backgroundColor: isStatusSelected(label.id) ? label.color : 'transparent',
                  color: isStatusSelected(label.id) ? 'white' : label.color,
                  borderColor: label.color
                }}
              >
                {label.name}
                {isStatusSelected(label.id) && (
                  <span className="ml-1 text-xs">✓</span>
                )}
              </button>
            ))}

            {/* Filter Button - positioned after status labels */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`p-2 border rounded-lg transition-colors ${
                hasActiveSpecificFilters() 
                  ? 'bg-blue-50 border-blue-200 text-blue-600' 
                  : 'hover:bg-gray-50 text-gray-600'
              }`}
              title="Toggle filters"
            >
              <Filter className="h-5 w-5" />
            </button>

            {/* Clear All Filters Button */}
            {hasActiveFilters() && (
              <button
                onClick={clearAllFilters}
                className="p-2 border rounded-lg text-red-600 hover:bg-red-50 transition-colors"
                title="Clear all filters"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="bg-white rounded-lg shadow-sm border p-4 space-y-4">
            {/* Search Input */}
            <div className="space-y-1">
              <label className="block text-xs font-medium text-gray-700">Search</label>
              <div className="relative">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder="Search by customer name, service object, or phone number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-8 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  autoComplete="off"
                  inputMode="search"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              <p className="text-xs text-gray-500">
                Tip: Searching will include archived (released) visits in results
              </p>
            </div>

            {/* Other Filters */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Intake Date Filter */}
              <div className="space-y-1">
                <label className="block text-xs font-medium text-gray-700">Intake Date</label>
                <div className="relative">
                  <Calendar className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <input
                    type="date"
                    value={intakeDate}
                    onChange={(e) => setIntakeDate(e.target.value)}
                    className="w-full pl-8 pr-8 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  {intakeDate && (
                    <button
                      onClick={() => setIntakeDate('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Release Date Filter */}
              <div className="space-y-1">
                <label className="block text-xs font-medium text-gray-700">Release Date</label>
                <div className="relative">
                  <Calendar className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <input
                    type="date"
                    value={releaseDate}
                    onChange={(e) => setReleaseDate(e.target.value)}
                    className="w-full pl-8 pr-8 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  {releaseDate && (
                    <button
                      onClick={() => setReleaseDate('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Mechanic Filter */}
              <div className="space-y-1">
                <label className="block text-xs font-medium text-gray-700">Mechanic</label>
                <div className="relative">
                  <User className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <select
                    value={mechanicFilter}
                    onChange={(e) => setMechanicFilter(e.target.value)}
                    className="w-full pl-8 pr-8 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 appearance-none bg-white"
                  >
                    <option value="">All Mechanics</option>
                    {mechanics.map(mechanic => (
                      <option key={mechanic.id} value={mechanic.id}>{mechanic.name}</option>
                    ))}
                  </select>
                  {mechanicFilter && (
                    <button
                      onClick={() => setMechanicFilter('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Show indicator when released visits are included */}
        {showingReleasedVisits() && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-sm text-blue-800">
              <span className="font-medium">Including archived visits:</span> Your search or filters are showing some released/archived visits along with active ones.
            </p>
          </div>
        )}
      </div>

      <div className="space-y-4">
        {filteredVisits.map((visit) => (
          <div
            key={visit.id}
            onClick={() => navigate(`/customer-visit/${visit.id}`)}
            className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{visit.serviceObject}</h3>
                <p className="text-gray-600 mt-1">{visit.customerName}</p>
              </div>
              <div className="flex flex-col items-end space-y-2">
                <span
                  className="px-2 py-1 rounded-full text-sm font-medium"
                  style={{
                    backgroundColor: `${getStatusColor(visit.status)}20`,
                    color: getStatusColor(visit.status)
                  }}
                >
                  {findLabelById(visit.status)?.name}
                </span>
                <div className="text-sm text-gray-500 text-right">
                  <p>Mechanic: {findMechanicById(visit.mechanic)?.name}</p>
                  <p>Release: {formatDate(visit.releaseDate)}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
        {filteredVisits.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <SearchIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No visits found</h3>
            <p className="text-gray-500 mb-4">
              {hasActiveFilters() 
                ? 'Try adjusting your filters or search terms'
                : 'Try searching for a customer name, service object, or phone number'
              }
            </p>
            {hasActiveFilters() && (
              <button
                onClick={clearAllFilters}
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                Clear all filters
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}