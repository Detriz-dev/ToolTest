import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search as SearchIcon } from 'lucide-react'
import { visits, findLabelById, findMechanicById } from '../data/constants'

export function SearchVisit() {
  const navigate = useNavigate()
  const [searchQuery, setSearchQuery] = useState('')

  // Filter visits based on search query (phone number or customer name)
  const filteredVisits = visits.filter(visit => {
    if (!searchQuery.trim()) return true
    
    const query = searchQuery.toLowerCase()
    return (
      visit.customerName.toLowerCase().includes(query) ||
      visit.phoneNumber.includes(searchQuery.trim())
    )
  }).sort((a, b) => {
    // First, sort by status: Released visits first
    const aStatus = findLabelById(a.status)
    const bStatus = findLabelById(b.status)
    
    const aIsReleased = aStatus?.name === 'Released'
    const bIsReleased = bStatus?.name === 'Released'
    
    if (aIsReleased && !bIsReleased) return -1
    if (!aIsReleased && bIsReleased) return 1
    
    // If both have same release status, sort by intake date (newest first)
    return new Date(b.intakeDate).getTime() - new Date(a.intakeDate).getTime()
  })

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const getStatusColor = (statusId: string) => {
    const status = findLabelById(statusId)
    return status?.color || '#gray-500'
  }

  return (
    <div className="space-y-6">
      {/* Search Input */}
      <div className="relative">
        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
        <input
          type="text"
          placeholder="Search by phone number or name"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 text-lg border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          autoComplete="off"
        />
      </div>

      {/* Results */}
      <div className="space-y-4">
        {filteredVisits.map((visit) => (
          <div
            key={visit.id}
            onClick={() => navigate(`/customer-visit/${visit.id}`)}
            className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h3 className="text-lg font-semibold text-gray-900">{visit.customerName}</h3>
                <p className="text-gray-600">{visit.serviceObject}</p>
                <p className="text-sm text-blue-600 font-medium">{visit.phoneNumber}</p>
              </div>
              <div className="flex flex-col items-end space-y-2">
                <span
                  className="px-3 py-1 rounded-full text-sm font-medium"
                  style={{
                    backgroundColor: `${getStatusColor(visit.status)}20`,
                    color: getStatusColor(visit.status)
                  }}
                >
                  {findLabelById(visit.status)?.name}
                </span>
                <div className="text-sm text-gray-500 text-right">
                  <p>Mechanic: {findMechanicById(visit.mechanic)?.name}</p>
                  <p>Intake: {formatDate(visit.intakeDate)}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {/* No results message */}
        {searchQuery && filteredVisits.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <SearchIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No visits found</h3>
            <p className="text-gray-500">
              No visits match "{searchQuery}". Try searching with a different name or phone number.
            </p>
          </div>
        )}
        
        {/* Empty state when no search query */}
        {!searchQuery && (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <SearchIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Search for visits</h3>
            <p className="text-gray-500">
              Enter a customer name or phone number to find visits
            </p>
          </div>
        )}
      </div>
    </div>
  )
}