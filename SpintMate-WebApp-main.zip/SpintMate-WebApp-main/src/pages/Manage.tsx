import React from 'react'
import { Link } from 'react-router-dom'
import { Users, Wrench, Tag, Bike, MessageSquare } from 'lucide-react'

interface ManageOption {
  title: string
  description: string
  icon: React.ReactNode
  path: string
  category: 'service' | 'communication'
}

export function Manage() {
  const manageOptions: ManageOption[] = [
    {
      title: 'Services',
      description: 'Configure service types and categories',
      icon: <Wrench className="h-6 w-6 text-blue-600" />,
      path: '/service-subjects',
      category: 'service'
    },
    {
      title: 'Service Parts',
      description: 'Manage service parts inventory',
      icon: <Bike className="h-6 w-6 text-blue-600" />,
      path: '/service-parts',
      category: 'service'
    },
    {
      title: 'Visit Labels',
      description: 'Customize visit status labels',
      icon: <Tag className="h-6 w-6 text-blue-600" />,
      path: '/visit-labels',
      category: 'service'
    },
    {
      title: 'Mechanics',
      description: 'Manage mechanics and their assignments',
      icon: <Users className="h-6 w-6 text-blue-600" />,
      path: '/mechanics',
      category: 'service'
    },
    {
      title: 'SMS Templates',
      description: 'Manage SMS message templates',
      icon: <MessageSquare className="h-6 w-6 text-blue-600" />,
      path: '/sms-templates',
      category: 'communication'
    }
  ]

  const serviceOptions = manageOptions.filter(option => option.category === 'service')
  const communicationOptions = manageOptions.filter(option => option.category === 'communication')

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
        {serviceOptions.map((option, index) => (
          <Link
            key={index}
            to={option.path}
            className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start space-x-4">
              <div className="p-2 bg-blue-50 rounded-lg">
                {option.icon}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{option.title}</h3>
                <p className="text-sm text-gray-500 mt-1">{option.description}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
        {communicationOptions.map((option, index) => (
          <Link
            key={index}
            to={option.path}
            className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start space-x-4">
              <div className="p-2 bg-blue-50 rounded-lg">
                {option.icon}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{option.title}</h3>
                <p className="text-sm text-gray-500 mt-1">{option.description}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}