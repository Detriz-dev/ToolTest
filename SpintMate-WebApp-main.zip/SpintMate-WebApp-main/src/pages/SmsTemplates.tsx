import React, { useState } from 'react'
import { Plus, Edit2, Trash2, X, MoreVertical, MessageSquare } from 'lucide-react'
import { Toast } from '../components/ui/Toast'
import { useToast } from '../hooks/useToast'

interface SmsTemplate {
  id: string
  name: string
  message: string
  type: 'confirmation' | 'summary' | 'reminder' | 'collection'
}

const defaultTemplates: SmsTemplate[] = [
  {
    id: '1',
    name: 'Receive confirmation',
    message: 'Dear {customerName}, we\'ve received your {serviceObject} for service. Your visit ID is #{visitId}.',
    type: 'confirmation'
  },
  {
    id: '2',
    name: 'Summary with price',
    message: 'Dear {customerName}, your {serviceObject} service is complete. Total cost: ${totalCost}. Ready for pickup.',
    type: 'summary'
  },
  {
    id: '3',
    name: 'Summary without price',
    message: 'Dear {customerName}, your {serviceObject} service is complete and ready for pickup.',
    type: 'summary'
  },
  {
    id: '4',
    name: 'Reminder about visit',
    message: 'Reminder: Your service appointment for {serviceObject} is scheduled for {intakeDate}.',
    type: 'reminder'
  },
  {
    id: '5',
    name: 'Reminder about collection',
    message: 'Reminder: Your {serviceObject} is ready for collection. Please pick it up at your earliest convenience.',
    type: 'reminder'
  },
  {
    id: '6',
    name: 'Collection confirmation',
    message: 'Thank you for collecting your {serviceObject}. We appreciate your business!',
    type: 'collection'
  }
]

export function SmsTemplates() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedTemplate, setSelectedTemplate] = useState<SmsTemplate | null>(null)
  const [templatesList, setTemplatesList] = useState(defaultTemplates)
  const [activeMenu, setActiveMenu] = useState<string | null>(null)
  const { toast, showToast, hideToast } = useToast()

  const handleDelete = (id: string) => {
    setTemplatesList(prev => prev.filter(t => t.id !== id))
    setActiveMenu(null)
    showToast('Successfully deleted!')
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const form = e.target as HTMLFormElement
    const formData = new FormData(form)
    const name = formData.get('name') as string
    const message = formData.get('message') as string
    const type = formData.get('type') as SmsTemplate['type']

    if (selectedTemplate) {
      setTemplatesList(prev => 
        prev.map(t => t.id === selectedTemplate.id ? { ...t, name, message, type } : t)
      )
      showToast('Successfully saved!')
    } else {
      const newTemplate = {
        id: String(Date.now()),
        name,
        message,
        type
      }
      setTemplatesList(prev => [...prev, newTemplate])
      showToast('Successfully added!')
    }
    setIsModalOpen(false)
    setSelectedTemplate(null)
  }

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">SMS Templates</h1>
          <button
            onClick={() => {
              setSelectedTemplate(null)
              setIsModalOpen(true)
            }}
            className="flex items-center px-4 py-2 border border-blue-600 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add Template
          </button>
        </div>

        <div className="space-y-4">
          {templatesList.map((template) => (
            <div
              key={template.id}
              className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <div className="flex items-center space-x-3">
                    <MessageSquare className="h-5 w-5 text-blue-600" />
                    <h3 className="text-lg font-semibold text-gray-900">{template.name}</h3>
                  </div>
                  <p className="text-gray-600 whitespace-pre-wrap">{template.message}</p>
                  <span className="inline-block px-2 py-1 text-sm font-medium bg-blue-100 text-blue-800 rounded-full">
                    {template.type.charAt(0).toUpperCase() + template.type.slice(1)}
                  </span>
                </div>
                <div className="relative">
                  {/* Mobile menu button */}
                  <button
                    onClick={() => setActiveMenu(activeMenu === template.id ? null : template.id)}
                    className="lg:hidden p-2 text-gray-600 hover:text-gray-900 rounded-full hover:bg-gray-100"
                  >
                    <MoreVertical className="h-5 w-5" />
                  </button>
                  {/* Desktop buttons */}
                  <div className="hidden lg:flex lg:space-x-2">
                    <button
                      onClick={() => {
                        setSelectedTemplate(template)
                        setIsModalOpen(true)
                      }}
                      className="p-2 text-gray-600 hover:text-blue-600 rounded-full hover:bg-gray-100"
                    >
                      <Edit2 className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(template.id)}
                      className="p-2 text-gray-600 hover:text-red-600 rounded-full hover:bg-gray-100"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                  {/* Mobile menu */}
                  {activeMenu === template.id && (
                    <div className="lg:hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 ring-1 ring-black ring-opacity-5 z-10">
                      <button
                        onClick={() => {
                          setSelectedTemplate(template)
                          setIsModalOpen(true)
                          setActiveMenu(null)
                        }}
                        className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        <Edit2 className="h-4 w-4 mr-2" />
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(template.id)}
                        className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {isModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-lg w-full m-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">
                  {selectedTemplate ? 'Edit Template' : 'Add New Template'}
                </h2>
                <button
                  onClick={() => {
                    setIsModalOpen(false)
                    setSelectedTemplate(null)
                  }}
                  className="p-1 hover:bg-gray-100 rounded-full"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Template Name
                  </label>
                  <input
                    name="name"
                    type="text"
                    defaultValue={selectedTemplate?.name}
                    required
                    className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Message
                  </label>
                  <textarea
                    name="message"
                    defaultValue={selectedTemplate?.message}
                    required
                    rows={4}
                    className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    Available variables: {'{customerName}'}, {'{serviceObject}'}, {'{visitId}'}, {'{totalCost}'}, {'{intakeDate}'}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Type
                  </label>
                  <select
                    name="type"
                    defaultValue={selectedTemplate?.type}
                    required
                    className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="confirmation">Confirmation</option>
                    <option value="summary">Summary</option>
                    <option value="reminder">Reminder</option>
                    <option value="collection">Collection</option>
                  </select>
                </div>
                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => {
                      setIsModalOpen(false)
                      setSelectedTemplate(null)
                    }}
                    className="px-4 py-2 border rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    {selectedTemplate ? 'Save Changes' : 'Add Template'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  )
}