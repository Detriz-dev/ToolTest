import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronDown, ChevronUp, Upload, Copy, Trash2, FileText, PenTool as Tool, Receipt, UserCircle, Calendar, MoreVertical, X, Lightbulb, AlertCircle, Plus } from 'lucide-react'
import { labels, mechanics, predefinedServices, predefinedServiceParts, customerInfos } from '../data/constants'
import { Toast } from '../components/ui/Toast'
import { useToast } from '../hooks/useToast'

interface AccordionSectionProps {
  title: string
  isOpen: boolean
  onToggle: () => void
  children: React.ReactNode
  icon: React.ReactNode
  total?: string
  hasError?: boolean
}

function AccordionSection({ title, isOpen, onToggle, children, icon, total, hasError }: AccordionSectionProps) {
  return (
    <div className="border rounded-none sm:rounded-lg overflow-hidden w-full bg-white">
      <button
        onClick={onToggle}
        className={`w-full px-6 py-6 flex items-center space-x-4 hover:shadow-md transition-all ${
          hasError ? 'bg-red-50 border border-red-200' : 'bg-white'
        }`}
      >
        <div className="p-2 bg-blue-50 rounded-lg">
          {React.cloneElement(icon as React.ReactElement, { className: 'h-6 w-6 text-blue-600' })}
        </div>
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        <div className="flex-1" />
        {total && (
          <span className="text-2xl font-medium text-blue-600 mr-3">{total}</span>
        )}
        {isOpen ? (
          <ChevronUp className="h-6 w-6 text-blue-600" />
        ) : (
          <ChevronDown className="h-6 w-6 text-blue-600" />
        )}
      </button>
      {isOpen && (
        <div className="p-4 pr-8 bg-white w-full border-t">
          {children}
        </div>
      )}
    </div>
  )
}

interface PhotoPreview {
  id: string;
  url: string;
  file: File;
}

interface ServiceInput {
  id: string;
  name: string;
  price: string;
}

interface PartInput {
  id: string;
  name: string;
  price: string;
}

interface ValidationErrors {
  phoneNumber?: string;
  email?: string;
  serviceObject?: string;
}

export function AddVisit() {
  const navigate = useNavigate()
  const { toast, showToast, hideToast } = useToast()
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    serviceScope: false,
    customerBicycle: false,
    scheduleStatus: false,
    recommendations: false,
    costSummary: false
  })

  const [notes, setNotes] = useState('')
  const [recommendations, setRecommendations] = useState('')
  const [serviceInputs, setServiceInputs] = useState<ServiceInput[]>([
    { id: '1', name: '', price: '' }
  ])
  const [partInputs, setPartInputs] = useState<PartInput[]>([
    { id: '1', name: '', price: '' }
  ])
  const [showServiceSuggestions, setShowServiceSuggestions] = useState<string | null>(null)
  const [showPartSuggestions, setShowPartSuggestions] = useState<string | null>(null)
  const [activeServiceMenu, setActiveServiceMenu] = useState<string | null>(null)
  const [activePartMenu, setActivePartMenu] = useState<string | null>(null)
  const [focusedInput, setFocusedInput] = useState<string | null>(null)
  
  // Customer autosuggestion states (only for phone number)
  const [showCustomerSuggestions, setShowCustomerSuggestions] = useState(false)
  
  // Validation feedback states
  const [highlightMissingFields, setHighlightMissingFields] = useState(false)
  const [missingServiceFields, setMissingServiceFields] = useState<Set<string>>(new Set())
  const [missingPartFields, setMissingPartFields] = useState<Set<string>>(new Set())
  
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    serviceObject: '',
    phoneNumber: '',
    email: ''
  })
  
  // Validation states
  const [validationErrors, setValidationErrors] = useState<ValidationErrors>({})
  const [touched, setTouched] = useState<Record<string, boolean>>({})
  
  // Set default values for schedule info
  const today = new Date().toISOString().split('T')[0]
  const noStatusLabel = labels.find(label => label.name === 'No Status')
  
  const [scheduleInfo, setScheduleInfo] = useState({
    intakeDate: today,
    releaseDate: '',
    statuses: noStatusLabel ? [noStatusLabel.id] : [] as string[],
    mechanic: ''
  })
  const [discounts, setDiscounts] = useState({
    services: 0,
    parts: 0
  })
  const [photos, setPhotos] = useState<PhotoPreview[]>([])

  // Validation functions
  const validatePhoneNumber = (phone: string): string | undefined => {
    if (!phone) return 'Phone number is required'
    
    // Remove all non-digit characters for validation
    const digitsOnly = phone.replace(/\D/g, '')
    
    // Check if it's a valid length (between 7-15 digits is generally acceptable internationally)
    if (digitsOnly.length < 7) {
      return 'Phone number must be at least 7 digits'
    }
    if (digitsOnly.length > 15) {
      return 'Phone number must be no more than 15 digits'
    }
    
    return undefined
  }

  const validateEmail = (email: string): string | undefined => {
    if (!email) return undefined // Optional field
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return 'Please enter a valid email address'
    }
    
    return undefined
  }

  const validateServiceObject = (serviceObject: string): string | undefined => {
    if (!serviceObject.trim()) return 'Service object is required'
    return undefined
  }

  const validateField = (name: string, value: string) => {
    let error: string | undefined

    switch (name) {
      case 'phoneNumber':
        error = validatePhoneNumber(value)
        break
      case 'email':
        error = validateEmail(value)
        break
      case 'serviceObject':
        error = validateServiceObject(value)
        break
      default:
        return
    }

    setValidationErrors(prev => ({
      ...prev,
      [name]: error
    }))
  }

  // Check if customer and bicycle section has validation errors
  const hasCustomerBicycleErrors = () => {
    return validationErrors.phoneNumber || validationErrors.email || validationErrors.serviceObject
  }

  // Check if an item is complete (has both name and price)
  const isItemComplete = (item: ServiceInput | PartInput): boolean => {
    return item.name.trim() !== '' && item.price.trim() !== ''
  }

  // Check if we can add a new service (last service is complete)
  const canAddService = (): boolean => {
    if (serviceInputs.length === 0) return true
    const lastService = serviceInputs[serviceInputs.length - 1]
    return isItemComplete(lastService)
  }

  // Check if we can add a new part (last part is complete)
  const canAddPart = (): boolean => {
    if (partInputs.length === 0) return true
    const lastPart = partInputs[partInputs.length - 1]
    return isItemComplete(lastPart)
  }

  // Get missing fields for an item
  const getMissingFields = (item: ServiceInput | PartInput): string[] => {
    const missing: string[] = []
    if (item.name.trim() === '') missing.push('name')
    if (item.price.trim() === '') missing.push('price')
    return missing
  }

  // Check if a specific field should be highlighted
  const shouldHighlightField = (itemId: string, field: 'name' | 'price', type: 'service' | 'part'): boolean => {
    if (!highlightMissingFields) return false
    
    const missingFields = type === 'service' ? missingServiceFields : missingPartFields
    return missingFields.has(`${itemId}-${field}`)
  }

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    const newPhotos = Array.from(files).map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      url: URL.createObjectURL(file),
      file
    }))

    setPhotos(prev => [...prev, ...newPhotos])
  }

  const removePhoto = (id: string) => {
    setPhotos(prev => {
      const filtered = prev.filter(photo => photo.id !== id)
      // Revoke the URL to prevent memory leaks
      const photoToRemove = prev.find(photo => photo.id === id)
      if (photoToRemove) {
        URL.revokeObjectURL(photoToRemove.url)
      }
      return filtered
    })
  }

  const handleSave = () => {
    // Validate all fields before saving
    const phoneError = validatePhoneNumber(customerInfo.phoneNumber)
    const emailError = validateEmail(customerInfo.email)
    const serviceObjectError = validateServiceObject(customerInfo.serviceObject)
    
    const errors: ValidationErrors = {}
    if (phoneError) errors.phoneNumber = phoneError
    if (emailError) errors.email = emailError
    if (serviceObjectError) errors.serviceObject = serviceObjectError
    
    setValidationErrors(errors)
    setTouched({
      phoneNumber: true,
      email: true,
      serviceObject: true
    })
    
    // If there are validation errors, don't save
    if (Object.keys(errors).length > 0) {
      // Scroll to the customer section if there are errors
      setOpenSections(prev => ({ ...prev, customerBicycle: true }))
      return
    }
    
    console.log('Saving visit...')
    showToast('Successfully saved!')
    navigate('/customer-visits')
  }

  const handleCancel = () => {
    navigate(-1)
  }

  const calculateTotalCost = () => {
    const servicesSubtotal = serviceInputs
      .filter(service => isItemComplete(service))
      .reduce((sum, service) => sum + (parseFloat(service.price) || 0), 0)
    const serviceDiscount = (servicesSubtotal * discounts.services) / 100
    const serviceTotal = servicesSubtotal - serviceDiscount
    
    const partsSubtotal = partInputs
      .filter(part => isItemComplete(part))
      .reduce((sum, part) => sum + (parseFloat(part.price) || 0), 0)
    const partsDiscount = (partsSubtotal * discounts.parts) / 100
    const partsTotal = partsSubtotal - partsDiscount

    return {
      servicesSubtotal,
      serviceDiscount,
      serviceTotal,
      partsSubtotal,
      partsDiscount,
      partsTotal,
      total: serviceTotal + partsTotal
    }
  }

  const handleServiceInputChange = (id: string, field: 'name' | 'price', value: string) => {
    setServiceInputs(prev => 
      prev.map(input =>
        input.id === id ? { ...input, [field]: value } : input
      )
    )
    
    // Clear highlighting for this field when user starts typing
    if (highlightMissingFields) {
      setMissingServiceFields(prev => {
        const newSet = new Set(prev)
        newSet.delete(`${id}-${field}`)
        return newSet
      })
    }
  }

  const handlePartInputChange = (id: string, field: 'name' | 'price', value: string) => {
    setPartInputs(prev => 
      prev.map(input =>
        input.id === id ? { ...input, [field]: value } : input
      )
    )
    
    // Clear highlighting for this field when user starts typing
    if (highlightMissingFields) {
      setMissingPartFields(prev => {
        const newSet = new Set(prev)
        newSet.delete(`${id}-${field}`)
        return newSet
      })
    }
  }

  const handleDuplicateService = (id: string) => {
    const serviceToDuplicate = serviceInputs.find(input => input.id === id)
    if (serviceToDuplicate && isItemComplete(serviceToDuplicate)) {
      const newService = {
        ...serviceToDuplicate,
        id: String(Date.now())
      }
      setServiceInputs(prev => [...prev, newService])
    }
    setActiveServiceMenu(null)
  }

  const handleDuplicatePart = (id: string) => {
    const partToDuplicate = partInputs.find(input => input.id === id)
    if (partToDuplicate && isItemComplete(partToDuplicate)) {
      const newPart = {
        ...partToDuplicate,
        id: String(Date.now())
      }
      setPartInputs(prev => [...prev, newPart])
    }
    setActivePartMenu(null)
  }

  const handleRemoveService = (id: string) => {
    setServiceInputs(prev => {
      const filtered = prev.filter(input => input.id !== id)
      // If we removed all items, add one empty item
      if (filtered.length === 0) {
        return [{ id: String(Date.now()), name: '', price: '' }]
      }
      return filtered
    })
    setActiveServiceMenu(null)
  }

  const handleRemovePart = (id: string) => {
    setPartInputs(prev => {
      const filtered = prev.filter(input => input.id !== id)
      // If we removed all items, add one empty item
      if (filtered.length === 0) {
        return [{ id: String(Date.now()), name: '', price: '' }]
      }
      return filtered
    })
    setActivePartMenu(null)
  }

  const handleDiscountChange = (type: 'services' | 'parts', value: string) => {
    const numValue = Math.min(Math.max(parseFloat(value) || 0, 0), 100)
    setDiscounts(prev => ({
      ...prev,
      [type]: numValue
    }))
  }

  const handleDiscountFocus = (type: 'services' | 'parts') => {
    // Clear the input if it's 0 when focused
    if (discounts[type] === 0) {
      setDiscounts(prev => ({
        ...prev,
        [type]: '' as any // Temporarily set to empty string for display
      }))
    }
  }

  const handleDiscountBlur = (type: 'services' | 'parts') => {
    // If empty on blur, set back to 0
    if (discounts[type] === '' || isNaN(discounts[type])) {
      setDiscounts(prev => ({
        ...prev,
        [type]: 0
      }))
    }
  }

  const filteredServices = (inputId: string) => {
    const input = serviceInputs.find(i => i.id === inputId)
    return input
      ? predefinedServices.filter(service =>
          service.name.toLowerCase().includes(input.name.toLowerCase())
        )
      : []
  }

  const filteredParts = (inputId: string) => {
    const input = partInputs.find(i => i.id === inputId)
    return input
      ? predefinedServiceParts.filter(part =>
          part.name.toLowerCase().includes(input.name.toLowerCase())
        )
      : []
  }

  const handleServiceSelect = (serviceId: string, service: typeof predefinedServices[0]) => {
    handleServiceInputChange(serviceId, 'name', service.name)
    handleServiceInputChange(serviceId, 'price', service.price.toString())
    setShowServiceSuggestions(null)
  }

  const handlePartSelect = (partId: string, part: typeof predefinedServiceParts[0]) => {
    handlePartInputChange(partId, 'name', part.name)
    handlePartInputChange(partId, 'price', part.price.toString())
    setShowPartSuggestions(null)
  }

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }

  const handleCustomerInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setCustomerInfo(prev => ({
      ...prev,
      [name]: value
    }))
    
    // Mark field as touched
    setTouched(prev => ({
      ...prev,
      [name]: true
    }))
    
    // Validate field on change and clear errors when user starts typing
    if (value.trim() !== '') {
      setValidationErrors(prev => ({
        ...prev,
        [name]: undefined
      }))
    } else {
      validateField(name, value)
    }
  }

  const handleScheduleInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setScheduleInfo(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleStatusToggle = (labelId: string) => {
    setScheduleInfo(prev => ({
      ...prev,
      statuses: prev.statuses.includes(labelId)
        ? prev.statuses.filter(id => id !== labelId)
        : [...prev.statuses, labelId]
    }))
  }

  const clearAllStatuses = () => {
    setScheduleInfo(prev => ({
      ...prev,
      statuses: []
    }))
  }

  const isStatusSelected = (statusId: string) => {
    return scheduleInfo.statuses.includes(statusId)
  }

  // Customer suggestion functions (only for phone number)
  const getFilteredCustomers = () => {
    if (!customerInfo.phoneNumber) return []
    
    return customerInfos.filter(customer => 
      customer.phoneNumber.includes(customerInfo.phoneNumber)
    )
  }

  const handleCustomerSelect = (customer: typeof customerInfos[0]) => {
    setCustomerInfo({
      name: customer.name,
      serviceObject: customerInfo.serviceObject, // Keep current service object
      phoneNumber: customer.phoneNumber,
      email: customer.email
    })
    setShowCustomerSuggestions(false)
    
    // Clear validation errors when selecting existing customer
    setValidationErrors(prev => ({
      ...prev,
      phoneNumber: undefined,
      email: undefined
    }))
  }

  const handleAddService = () => {
    if (canAddService()) {
      // Clear any previous highlighting
      setHighlightMissingFields(false)
      setMissingServiceFields(new Set())
      
      const newService = { id: String(Date.now()), name: '', price: '' }
      setServiceInputs(prev => [...prev, newService])
    } else {
      // Highlight missing fields in the last incomplete service
      const lastService = serviceInputs[serviceInputs.length - 1]
      const missingFields = getMissingFields(lastService)
      const missingFieldKeys = missingFields.map(field => `${lastService.id}-${field}`)
      
      setHighlightMissingFields(true)
      setMissingServiceFields(new Set(missingFieldKeys))
      
      // Clear highlighting after 3 seconds
      setTimeout(() => {
        setHighlightMissingFields(false)
        setMissingServiceFields(new Set())
      }, 3000)
    }
  }

  const handleAddPart = () => {
    if (canAddPart()) {
      // Clear any previous highlighting
      setHighlightMissingFields(false)
      setMissingPartFields(new Set())
      
      const newPart = { id: String(Date.now()), name: '', price: '' }
      setPartInputs(prev => [...prev, newPart])
    } else {
      // Highlight missing fields in the last incomplete part
      const lastPart = partInputs[partInputs.length - 1]
      const missingFields = getMissingFields(lastPart)
      const missingFieldKeys = missingFields.map(field => `${lastPart.id}-${field}`)
      
      setHighlightMissingFields(true)
      setMissingPartFields(new Set(missingFieldKeys))
      
      // Clear highlighting after 3 seconds
      setTimeout(() => {
        setHighlightMissingFields(false)
        setMissingPartFields(new Set())
      }, 3000)
    }
  }

  const costs = calculateTotalCost()

  return (
    <>
      <div className="pb-24 -mx-4 sm:mx-0">
        <div className="space-y-4">
          <AccordionSection
            title="Service Scope"
            isOpen={openSections.serviceScope}
            onToggle={() => toggleSection('serviceScope')}
            icon={<FileText />}
          >
            <div className="space-y-6 w-full">
              <div className="w-full">
                <h3 className="block text-sm font-medium text-gray-700 mb-1">Services</h3>
                <div className="space-y-2 w-full">
                  {serviceInputs.map((input) => (
                    <div key={input.id} className="flex items-center space-x-2">
                      <div className={`relative ${focusedInput === input.id ? 'flex-1' : 'flex-1'}`}>
                        <input
                          type="text"
                          placeholder="Type service"
                          value={input.name}
                          onChange={(e) => {
                            handleServiceInputChange(input.id, 'name', e.target.value)
                            setShowServiceSuggestions(input.id)
                          }}
                          onFocus={() => {
                            setFocusedInput(input.id)
                            setShowServiceSuggestions(input.id)
                          }}
                          onBlur={() => {
                            setTimeout(() => {
                              setFocusedInput(null)
                            }, 200)
                          }}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                            shouldHighlightField(input.id, 'name', 'service')
                              ? 'border-red-400 ring-2 ring-red-200'
                              : ''
                          }`}
                        />
                        {showServiceSuggestions === input.id && input.name && (
                          <div className="absolute z-10 left-0 right-0 mt-1 bg-white border rounded-lg shadow-lg max-h-60 overflow-auto">
                            {filteredServices(input.id).map((service) => (
                              <button
                                key={service.id}
                                onClick={() => handleServiceSelect(input.id, service)}
                                className="w-full px-4 py-2 text-left hover:bg-gray-50 focus:outline-none"
                              >
                                <span className="font-medium">{service.name}</span>
                                {service.price > 0 && (
                                  <span className="text-sm text-gray-500 ml-2">${service.price}</span>
                                )}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      <input
                        type="number"
                        min="1"
                        placeholder="0 $"
                        value={input.price}
                        onChange={(e) => handleServiceInputChange(input.id, 'price', e.target.value)}
                        className={`w-24 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                          focusedInput === input.id ? 'hidden md:block' : 'block'
                        } ${
                          shouldHighlightField(input.id, 'price', 'service')
                            ? 'border-red-400 ring-2 ring-red-200'
                            : ''
                        }`}
                      />
                      <div className="relative">
                        <button
                          onClick={() => setActiveServiceMenu(activeServiceMenu === input.id ? null : input.id)}
                          className="lg:hidden p-2 text-gray-600 hover:text-gray-900 rounded-full hover:bg-gray-100"
                        >
                          <MoreVertical className="h-5 w-5" />
                        </button>
                        <div className="hidden lg:flex lg:space-x-1">
                          <button
                            onClick={() => handleDuplicateService(input.id)}
                            disabled={!isItemComplete(input)}
                            className={`p-2 rounded-lg hover:bg-gray-100 ${
                              !isItemComplete(input)
                                ? 'text-gray-300 cursor-not-allowed'
                                : 'text-gray-600 hover:text-blue-600'
                            }`}
                            title="Duplicate"
                          >
                            <Copy className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleRemoveService(input.id)}
                            className="p-2 text-gray-600 hover:text-red-600 rounded-lg hover:bg-gray-100"
                            title="Remove"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                        {activeServiceMenu === input.id && (
                          <div className="lg:hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 ring-1 ring-black ring-opacity-5 z-10">
                            <button
                              onClick={() => handleDuplicateService(input.id)}
                              disabled={!isItemComplete(input)}
                              className={`flex items-center w-full px-4 py-2 text-sm hover:bg-gray-100 ${
                                !isItemComplete(input)
                                  ? 'text-gray-400 cursor-not-allowed'
                                  : 'text-gray-700'
                              }`}
                            >
                              <Copy className="h-4 w-4 mr-2" />
                              Duplicate
                            </button>
                            <button
                              onClick={() => handleRemoveService(input.id)}
                              className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  <button
                    onClick={handleAddService}
                    className={`flex items-center justify-center w-full px-3 py-2 border-2 border-dashed rounded-lg transition-colors ${
                      canAddService()
                        ? 'border-blue-300 text-blue-600 hover:border-blue-400 hover:text-blue-700 hover:bg-blue-50'
                        : 'border-blue-300 text-blue-600 hover:border-blue-400 hover:text-blue-700 hover:bg-blue-50'
                    }`}
                  >
                    <Plus className="h-5 w-5 mr-2" />
                    Add Service
                  </button>
                </div>
              </div>

              <div className="w-full">
                <h3 className="block text-sm font-medium text-gray-700 mb-1">Service Parts</h3>
                <div className="space-y-2 w-full">
                  {partInputs.map((input) => (
                    <div key={input.id} className="flex items-center space-x-2">
                      <div className={`relative ${focusedInput === input.id ? 'flex-1' : 'flex-1'}`}>
                        <input
                          type="text"
                          placeholder="Type service part"
                          value={input.name}
                          onChange={(e) => {
                            handlePartInputChange(input.id, 'name', e.target.value)
                            setShowPartSuggestions(input.id)
                          }}
                          onFocus={() => {
                            setFocusedInput(input.id)
                            setShowPartSuggestions(input.id)
                          }}
                          onBlur={() => {
                            setTimeout(() => {
                              setFocusedInput(null)
                            }, 200)
                          }}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                            shouldHighlightField(input.id, 'name', 'part')
                              ? 'border-red-400 ring-2 ring-red-200'
                              : ''
                          }`}
                        />
                        {showPartSuggestions === input.id && input.name && (
                          <div className="absolute z-10 left-0 right-0 mt-1 bg-white border rounded-lg shadow-lg max-h-60 overflow-auto">
                            {filteredParts(input.id).map((part) => (
                              <button
                                key={part.id}
                                onClick={() => handlePartSelect(input.id, part)}
                                className="w-full px-4 py-2 text-left hover:bg-gray-50 focus:outline-none"
                              >
                                <span className="font-medium">{part.name}</span>
                                {part.price > 0 && (
                                  <span className="text-sm text-gray-500 ml-2">${part.price}</span>
                                )}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      <input
                        type="number"
                        min="1"
                        placeholder="0 $"
                        value={input.price}
                        onChange={(e) => handlePartInputChange(input.id, 'price', e.target.value)}
                        className={`w-24 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                          focusedInput === input.id ? 'hidden md:block' : 'block'
                        } ${
                          shouldHighlightField(input.id, 'price', 'part')
                            ? 'border-red-400 ring-2 ring-red-200'
                            : ''
                        }`}
                      />
                      <div className="relative">
                        <button
                          onClick={() => setActivePartMenu(activePartMenu === input.id ? null : input.id)}
                          className="lg:hidden p-2 text-gray-600 hover:text-gray-900 rounded-full hover:bg-gray-100"
                        >
                          <MoreVertical className="h-5 w-5" />
                        </button>
                        <div className="hidden lg:flex lg:space-x-1">
                          <button
                            onClick={() => handleDuplicatePart(input.id)}
                            disabled={!isItemComplete(input)}
                            className={`p-2 rounded-lg hover:bg-gray-100 ${
                              !isItemComplete(input)
                                ? 'text-gray-300 cursor-not-allowed'
                                : 'text-gray-600 hover:text-blue-600'
                            }`}
                            title="Duplicate"
                          >
                            <Copy className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleRemovePart(input.id)}
                            className="p-2 text-gray-600 hover:text-red-600 rounded-lg hover:bg-gray-100"
                            title="Remove"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                        {activePartMenu === input.id && (
                          <div className="lg:hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 ring-1 ring-black ring-opacity-5 z-10">
                            <button
                              onClick={() => handleDuplicatePart(input.id)}
                              disabled={!isItemComplete(input)}
                              className={`flex items-center w-full px-4 py-2 text-sm hover:bg-gray-100 ${
                                !isItemComplete(input)
                                  ? 'text-gray-400 cursor-not-allowed'
                                  : 'text-gray-700'
                              }`}
                            >
                              <Copy className="h-4 w-4 mr-2" />
                              Duplicate
                            </button>
                            <button
                              onClick={() => handleRemovePart(input.id)}
                              className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  <button
                    onClick={handleAddPart}
                    className={`flex items-center justify-center w-full px-3 py-2 border-2 border-dashed rounded-lg transition-colors ${
                      canAddPart()
                        ? 'border-blue-300 text-blue-600 hover:border-blue-400 hover:text-blue-700 hover:bg-blue-50'
                        : 'border-blue-300 text-blue-600 hover:border-blue-400 hover:text-blue-700 hover:bg-blue-50'
                    }`}
                  >
                    <Plus className="h-5 w-5 mr-2" />
                    Add Part
                  </button>
                </div>
              </div>

              <div className="w-full">
                <h3 className="block text-sm font-medium text-gray-700 mb-1">Notes</h3>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={4}
                  className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Add any additional notes or instructions..."
                />
              </div>
            </div>
          </AccordionSection>

          <AccordionSection
            title="Customer and Bicycle"
            isOpen={openSections.customerBicycle}
            onToggle={() => toggleSection('customerBicycle')}
            icon={hasCustomerBicycleErrors() ? <AlertCircle className="h-6 w-6 text-red-600" /> : <UserCircle />}
            hasError={hasCustomerBicycleErrors()}
          >
            <div className="space-y-6 px-4 sm:px-0">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="serviceObject" className="block text-sm font-medium text-gray-700 mb-1">
                    Service Object <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="serviceObject"
                    name="serviceObject"
                    value={customerInfo.serviceObject}
                    onChange={handleCustomerInfoChange}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                      validationErrors.serviceObject && touched.serviceObject ? 'border-red-500' : ''
                    }`}
                    placeholder="Enter service object"
                  />
                  {validationErrors.serviceObject && touched.serviceObject && (
                    <div className="mt-1 flex items-center text-sm text-red-600">
                      <AlertCircle className="h-4 w-4 mr-1" />
                      {validationErrors.serviceObject}
                    </div>
                  )}
                </div>

                <div className="relative">
                  <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    id="phoneNumber"
                    name="phoneNumber"
                    value={customerInfo.phoneNumber}
                    onChange={(e) => {
                      handleCustomerInfoChange(e)
                      setShowCustomerSuggestions(true)
                    }}
                    onFocus={() => setShowCustomerSuggestions(true)}
                    onBlur={() => setTimeout(() => setShowCustomerSuggestions(false), 200)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                      validationErrors.phoneNumber && touched.phoneNumber ? 'border-red-500' : ''
                    }`}
                    placeholder="Enter phone number"
                  />
                  {validationErrors.phoneNumber && touched.phoneNumber && (
                    <div className="mt-1 flex items-center text-sm text-red-600">
                      <AlertCircle className="h-4 w-4 mr-1" />
                      {validationErrors.phoneNumber}
                    </div>
                  )}
                  {showCustomerSuggestions && getFilteredCustomers().length > 0 && (
                    <div className="absolute z-10 left-0 right-0 mt-1 bg-white border rounded-lg shadow-lg max-h-60 overflow-auto">
                      <div className="p-2 bg-gray-50 border-b">
                        <p className="text-xs text-gray-600 font-medium">Existing Customers</p>
                      </div>
                      {getFilteredCustomers().map((customer) => (
                        <button
                          key={customer.id}
                          onClick={() => handleCustomerSelect(customer)}
                          className="w-full px-4 py-3 text-left hover:bg-gray-50 focus:outline-none border-b border-gray-100 last:border-b-0"
                        >
                          <div>
                            <p className="font-medium text-gray-900">{customer.name}</p>
                            <p className="text-sm text-gray-600">{customer.phoneNumber}</p>
                            <p className="text-sm text-gray-500">{customer.email}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Client Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={customerInfo.name}
                    onChange={handleCustomerInfoChange}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter client name"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={customerInfo.email}
                    onChange={handleCustomerInfoChange}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                      validationErrors.email && touched.email ? 'border-red-500' : ''
                    }`}
                    placeholder="Enter email address"
                  />
                  {validationErrors.email && touched.email && (
                    <div className="mt-1 flex items-center text-sm text-red-600">
                      <AlertCircle className="h-4 w-4 mr-1" />
                      {validationErrors.email}
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Service Object Photos
                </label>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {photos.map((photo) => (
                      <div key={photo.id} className="relative aspect-square rounded-lg overflow-hidden group">
                        <img
                          src={photo.url}
                          alt="Preview"
                          className="w-full h-full object-cover"
                        />
                        <button
                          onClick={() => removePhoto(photo.id)}
                          className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    <label className="relative aspect-square border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-gray-400 transition-colors">
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="sr-only"
                      />
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <Upload className="h-6 w-6 text-gray-400" />
                        <span className="mt-2 text-sm text-gray-500">Add Photos</span>
                      </div>
                    </label>
                  </div>
                  <p className="text-sm text-gray-500">
                    Upload multiple photos of the service object. Click on a photo to remove it.
                  </p>
                </div>
              </div>
            </div>
          </AccordionSection>

          <AccordionSection
            title="Schedule and Status"
            isOpen={openSections.scheduleStatus}
            onToggle={() => toggleSection('scheduleStatus')}
            icon={<Calendar />}
          >
            <div className="space-y-6 px-4 sm:px-0">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="intakeDate" className="block text-sm font-medium text-gray-700 mb-1">
                    Intake Date
                  </label>
                  <input
                    type="date"
                    id="intakeDate"
                    name="intakeDate"
                    value={scheduleInfo.intakeDate}
                    onChange={handleScheduleInfoChange}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label htmlFor="releaseDate" className="block text-sm font-medium text-gray-700 mb-1">
                    Release Date
                  </label>
                  <input
                    type="date"
                    id="releaseDate"
                    name="releaseDate"
                    value={scheduleInfo.releaseDate}
                    onChange={handleScheduleInfoChange}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-medium text-gray-700">
                    Status (Multiple Selection)
                  </label>
                  {scheduleInfo.statuses.length > 0 && (
                    <button
                      onClick={clearAllStatuses}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
                    >
                      <X className="h-4 w-4 mr-1" />
                      Clear all
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-2">
                  {labels.map(label => (
                    <button
                      key={label.id}
                      onClick={() => handleStatusToggle(label.id)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-colors border-2`}
                      style={{
                        backgroundColor: isStatusSelected(label.id) ? label.color : 'transparent',
                        color: isStatusSelected(label.id) ? 'white' : label.color,
                        borderColor: label.color
                      }}
                    >
                      {label.name}
                      {isStatusSelected(label.id) && (
                        <span className="ml-2 text-xs">✓</span>
                      )}
                    </button>
                  ))}
                </div>
                {scheduleInfo.statuses.length > 0 && (
                  <div className="mt-2 text-sm text-gray-600">
                    Selected statuses: {scheduleInfo.statuses.map(id => labels.find(l => l.id === id)?.name).join(', ')}
                  </div>
                )}
              </div>

              <div>
                <label htmlFor="mechanic" className="block text-sm font-medium text-gray-700 mb-1">
                  Mechanic
                </label>
                <select
                  id="mechanic"
                  name="mechanic"
                  value={scheduleInfo.mechanic}
                  onChange={handleScheduleInfoChange}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select mechanic</option>
                  {mechanics.map(mechanic => (
                    <option key={mechanic.id} value={mechanic.id}>
                      {mechanic.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </AccordionSection>

          <AccordionSection
            title="Recommendations"
            isOpen={openSections.recommendations}
            onToggle={() => toggleSection('recommendations')}
            icon={<Lightbulb />}
          >
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Additional Recommendations
                </label>
                <textarea
                  value={recommendations}
                  onChange={(e) => setRecommendations(e.target.value)}
                  rows={4}
                  className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Add any recommendations for future service or maintenance..."
                />
              </div>
            </div>
          </AccordionSection>

          <AccordionSection
            title="Discount"
            isOpen={openSections.costSummary}
            onToggle={() => toggleSection('costSummary')}
            icon={<Receipt />}
          >
            <div className="space-y-4 px-4 sm:px-0">
              <div className="flex justify-between items-center py-2 border-b">
                <div className="space-y-1">
                  
                  <h3 className="block text-sm font-medium text-gray-700">Services Subtotal</h3>
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={discounts.services === 0 ? '' : discounts.services}
                      onChange={(e) => handleDiscountChange('services', e.target.value)}
                      onFocus={() => handleDiscountFocus('services')}
                      onBlur={() => handleDiscountBlur('services')}
                      className="w-20 px-2 py-1 text-sm border rounded focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                    <span className="text-sm text-gray-500">% discount</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">${costs.servicesSubtotal.toFixed(2)}</div>
                  <div className="text-sm text-red-500">-${costs.serviceDiscount.toFixed(2)}</div>
                  <div className="font-medium">${costs.serviceTotal.toFixed(2)}</div>
                </div>
              </div>
              
              <div className="flex justify-between items-center py-2 border-b">
                <div className="space-y-1">
                  <h3 className="block text-sm font-medium text-gray-700">Parts Subtotal</h3>
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={discounts.parts === 0 ? '' : discounts.parts}
                      onChange={(e) => handleDiscountChange('parts', e.target.value)}
                      onFocus={() => handleDiscountFocus('parts')}
                      onBlur={() => handleDiscountBlur('parts')}
                      className="w-20 px-2 py-1 text-sm border rounded focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                    <span className="text-sm text-gray-500">% discount</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">${costs.partsSubtotal.toFixed(2)}</div>
                  <div className="text-sm text-red-500">-${costs.partsDiscount.toFixed(2)}</div>
                  <div className="font-medium">${costs.partsTotal.toFixed(2)}</div>
                </div>
              </div>
              
              <div className="flex justify-between items-center py-2 text-lg font-semibold">
                <h3 className="block text-sm font-medium text-gray-700">Total Cost</h3>
                <span className="text-blue-600">${costs.total.toFixed(2)}</span>
              </div>
            </div>
          </AccordionSection>
        </div>

        <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4 flex justify-between items-center">
          <div className="text-left">
            <span className="text-sm text-gray-500">Total Cost</span>
            <div className="text-2xl font-bold text-blue-600">${costs.total.toFixed(2)}</div>
          </div>
          <div className="flex space-x-3">
            <button
              onClick={handleCancel}
              className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Save Visit
            </button>
          </div>
        </div>
      </div>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  )
}