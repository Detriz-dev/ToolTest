import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowLeft, ChevronDown, ChevronUp, PenTool as Tool, Receipt, Calendar, UserCircle, FileText, MessageSquare, Link as LinkIcon, QrCode, Copy, Check, Share2, Send, Edit2, X, ChevronLeft, ChevronRight, Maximize2, Minimize2, Lightbulb, Trash2, Phone } from 'lucide-react'
import { findVisitById, findLabelById, findMechanicById } from '../data/constants'
import QRCode from 'qrcode'
import { Swiper, SwiperSlide } from 'swiper/react'
import { Navigation, Pagination } from 'swiper/modules'
import 'swiper/css'
import 'swiper/css/navigation'
import 'swiper/css/pagination'

interface AccordionSectionProps {
  title: string
  isOpen: boolean
  onToggle: () => void
  children: React.ReactNode
  icon: React.ReactNode
  total?: string
}

function AccordionSection({ title, isOpen, onToggle, children, icon, total }: AccordionSectionProps) {
  return (
    <div className="border rounded-lg overflow-hidden w-full bg-white">
      <button
        onClick={onToggle}
        className="w-full px-6 py-6 flex items-center space-x-4 bg-white hover:shadow-md transition-all"
      >
        <div className="p-2 bg-blue-50 rounded-lg">
          {React.cloneElement(icon as React.ReactElement, { className: 'h-6 w-6 text-blue-600' })}
        </div>
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        <div className="flex-1" />
        {total && (
          <span className="text-2xl font-medium text-blue-600 mr-3">{total}</span>
        )}
        {isOpen ? (
          <ChevronUp className="h-6 w-6 text-blue-600" />
        ) : (
          <ChevronDown className="h-6 w-6 text-blue-600" />
        )}
      </button>
      {isOpen && (
        <div className="p-6 bg-white w-full border-t">
          {children}
        </div>
      )}
    </div>
  )
}

const formatDate = (dateString: string) => {
  const date = new Date(dateString)
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })
}

export function CustomerVisit() {
  const { id } = useParams()
  const navigate = useNavigate()
  const visit = findVisitById(id || '')
  const [activeTab, setActiveTab] = useState<'details' | 'share' | 'communication'>('details')
  const [qrCodeUrl, setQrCodeUrl] = useState('')
  const [copied, setCopied] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    serviceScope: false,
    customerBicycle: false,
    scheduleStatus: false,
    recommendations: false,
    costSummary: false,
  })
  const [editMessageModal, setEditMessageModal] = useState<{
    isOpen: boolean;
    type: string;
    message: string;
  }>({
    isOpen: false,
    type: '',
    message: ''
  })
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [activeSlide, setActiveSlide] = useState(0)

  const photos = [
    "https://images.pexels.com/photos/100582/pexels-photo-100582.jpeg",
    "https://images.pexels.com/photos/276517/pexels-photo-276517.jpeg",
    "https://images.pexels.com/photos/1149601/pexels-photo-1149601.jpeg"
  ]

  const visitUrl = `${window.location.origin}/customer-visit/${id}`

  const defaultMessages = {
    confirmation: `Dear ${visit?.customerName}, we've received your ${visit?.serviceObject} for service. Your visit ID is #${visit?.id}.`,
    summaryWithPrice: `Dear ${visit?.customerName}, your ${visit?.serviceObject} service is complete. Total cost: $${visit?.totalCost}. Ready for pickup.`,
    summaryWithoutPrice: `Dear ${visit?.customerName}, your ${visit?.serviceObject} service is complete and ready for pickup.`,
    reminderVisit: `Reminder: Your service appointment for ${visit?.serviceObject} is scheduled for ${formatDate(visit?.intakeDate || '')}.`,
    reminderCollection: `Reminder: Your ${visit?.serviceObject} is ready for collection. Please pick it up at your earliest convenience.`,
    collectionConfirmation: `Thank you for collecting your ${visit?.serviceObject}. We appreciate your business!`
  }

  const formatSentDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleSendSMS = (type: string) => {
    console.log(`Sending SMS: ${type}`)
    // Implement SMS sending logic here
  }

  const handleEditMessage = (type: string) => {
    setEditMessageModal({
      isOpen: true,
      type,
      message: defaultMessages[type as keyof typeof defaultMessages]
    })
  }

  const handleDeleteVisit = () => {
    // Here you would implement the actual delete logic
    console.log(`Deleting visit with ID: ${id}`)
    
    // For now, just navigate back to the search page
    // In a real app, you would make an API call to delete the visit
    navigate('/search-visit')
  }

  const handlePhoneCall = () => {
    if (visit?.phoneNumber) {
      // Create tel: link to initiate phone call
      window.location.href = `tel:${visit.phoneNumber}`
    }
  }

  useEffect(() => {
    if (visit) {
      QRCode.toDataURL(visitUrl)
        .then(url => setQrCodeUrl(url))
        .catch(err => console.error('Error generating QR code:', err))
    }
  }, [visitUrl])

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(visitUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  if (!visit) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold text-gray-900">Visit not found</h1>
        <button
          onClick={() => navigate('/search')}
          className="mt-4 inline-flex items-center text-blue-600 hover:text-blue-700"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Search
        </button>
      </div>
    )
  }

  const status = findLabelById(visit.status)
  const mechanic = findMechanicById(visit.mechanic)

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }

  const servicesTotal = visit.services.reduce((sum, service) => sum + service.price, 0)
  const partsTotal = visit.parts.reduce((sum, part) => sum + part.price, 0)

  const serviceDiscount = 10
  const partsDiscount = 5

  const serviceDiscountAmount = (servicesTotal * serviceDiscount) / 100
  const partsDiscountAmount = (partsTotal * partsDiscount) / 100

  const servicesAfterDiscount = servicesTotal - serviceDiscountAmount
  const partsAfterDiscount = partsTotal - partsDiscountAmount

  const totalDiscount = serviceDiscountAmount + partsDiscountAmount
  const totalAfterDiscount = servicesAfterDiscount + partsAfterDiscount

  return (
    <>
      <style>
        {`
          .swiper-button-next,
          .swiper-button-prev {
            width: 40px !important;
            height: 40px !important;
            background-color: white !important;
            border-radius: 50% !important;
            color: #2563eb !important;
          }

          .swiper-button-next:after,
          .swiper-button-prev:after {
            font-size: 20px !important;
          }

          .swiper-button-next.swiper-button-disabled,
          .swiper-button-prev.swiper-button-disabled {
            opacity: 0.35;
            pointer-events: none;
          }
        `}
      </style>

      {/* Mobile Top Navigation Bar */}
      <nav className="lg:hidden fixed top-0 left-0 right-0 bg-white shadow-sm z-50">
        <div className="px-4 h-16 flex justify-between items-center">
          <div className="flex items-center flex-1">
            <h1 className="text-lg font-semibold text-gray-900 ml-2">
              Visit Details
            </h1>
          </div>
          <div className="flex items-center space-x-2">
            {visit.phoneNumber && (
              <button
                onClick={handlePhoneCall}
                className="flex items-center px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                title={`Call ${visit.phoneNumber}`}
              >
                <Phone className="h-4 w-4 mr-1" />
                Call
              </button>
            )}
            <button
              onClick={() => setShowDeleteDialog(true)}
              className="flex items-center justify-center w-10 h-10 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              title="Delete visit"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Action Bar */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4 flex justify-between items-center z-50">
        <div className="text-left">
          <span className="text-sm text-gray-500">Total Cost</span>
          <div className="text-2xl font-bold text-blue-600">${visit.totalCost.toFixed(2)}</div>
        </div>
        <button
          onClick={() => navigate(`/customer-visit/${id}/edit`)}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Edit Visit
        </button>
      </div>

      {/* Desktop Bottom Action Bar */}
      <div className="hidden lg:block fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="text-left">
              <span className="text-sm text-gray-500">Total Cost</span>
              <div className="text-2xl font-bold text-blue-600">${visit.totalCost.toFixed(2)}</div>
            </div>
            <button
              onClick={() => navigate(`/customer-visit/${id}/edit`)}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Edit Visit
            </button>
          </div>
        </div>
      </div>

      <div className="space-y-6 -mx-4 sm:mx-0 pb-24">
        {/* Desktop Header */}
        <div className="hidden lg:flex items-center justify-between px-4 sm:px-0">
          <div className="flex items-center space-x-4">
            <h1 className="text-3xl font-bold text-gray-900">Visit Details</h1>
          </div>
          <div className="flex items-center space-x-3">
            {visit.phoneNumber && (
              <button
                onClick={handlePhoneCall}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                title={`Call ${visit.phoneNumber}`}
              >
                <Phone className="h-5 w-5 mr-2" />
                Call
              </button>
            )}
            <button
              onClick={() => setShowDeleteDialog(true)}
              className="flex items-center justify-center w-10 h-10 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              title="Delete visit"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Delete Confirmation Dialog */}
        {showDeleteDialog && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-2 bg-red-50 rounded-lg">
                  <Trash2 className="h-6 w-6 text-red-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Delete Visit</h3>
              </div>
              <p className="text-gray-600 mb-6">
                Are you sure that you want to delete this visit? This action cannot be undone.
              </p>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setShowDeleteDialog(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteVisit}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  Delete Visit
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Photo Slider */}
        <div className="relative">
          <div className={`${isFullscreen ? 'fixed inset-0 z-50 bg-black' : 'relative h-64'} rounded-none sm:rounded-lg overflow-hidden`}>
            <Swiper
              modules={[Navigation, Pagination]}
              navigation
              pagination={{ clickable: true }}
              onSlideChange={(swiper) => setActiveSlide(swiper.activeIndex)}
              className="h-full"
            >
              {photos.map((photo, index) => (
                <SwiperSlide key={index}>
                  <img
                    src={photo}
                    alt={`Service photo ${index + 1}`}
                    className={`w-full ${isFullscreen ? 'h-screen object-contain' : 'h-64 object-cover'}`}
                  />
                </SwiperSlide>
              ))}
            </Swiper>
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent pointer-events-none" />
            
            <div className="absolute bottom-4 left-4 text-white z-10">
              <h2 className="text-3xl font-bold mb-2">{visit.serviceObject}</h2>
              <p className="text-sm opacity-90">Service ID: #{visit.id}</p>
            </div>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="absolute top-4 right-4 p-2 bg-black/50 rounded-full text-white z-10 hover:bg-black/75 transition-colors"
            >
              {isFullscreen ? (
                <Minimize2 className="h-5 w-5" />
              ) : (
                <Maximize2 className="h-5 w-5" />
              )}
            </button>

            {isFullscreen && (
              <button
                onClick={() => setIsFullscreen(false)}
                className="absolute top-4 left-4 p-2 bg-black/50 rounded-full text-white z-10 hover:bg-black/75 transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>

        <div className="border-b border-gray-200 px-4 sm:px-0">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('details')}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                ${activeTab === 'details'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }
              `}
            >
              <FileText className="h-5 w-5 mr-2" />
              Details
            </button>
            <button
              onClick={() => setActiveTab('communication')}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                ${activeTab === 'communication'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }
              `}
            >
              <MessageSquare className="h-5 w-5 mr-2" />
              Communication
            </button>
            <button
              onClick={() => setActiveTab('share')}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                ${activeTab === 'share'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }
              `}
            >
              <Share2 className="h-5 w-5 mr-2" />
              Share
            </button>
          </nav>
        </div>

        {activeTab === 'details' && (
          <div className="space-y-4 px-4 sm:px-0">
            <AccordionSection
              title="Service Scope"
              isOpen={openSections.serviceScope}
              onToggle={() => toggleSection('serviceScope')}
              icon={<FileText />}
            >
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Services</h3>
                  <div className="space-y-2">
                    {visit.services.map((service, index) => (
                      <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-gray-900">{service.name}</span>
                        <span className="font-medium">${service.price}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-2 text-right">
                    <span className="text-sm text-gray-600">Total: </span>
                    <span className="font-medium">${servicesTotal}</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Parts</h3>
                  <div className="space-y-2">
                    {visit.parts.map((part, index) => (
                      <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-gray-900">{part.name}</span>
                        <span className="font-medium">${part.price}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-2 text-right">
                    <span className="text-sm text-gray-600">Total: </span>
                    <span className="font-medium">${partsTotal}</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Notes</h3>
                  <p className="p-3 bg-gray-50 rounded-lg text-gray-900">{visit.notes}</p>
                </div>
              </div>
            </AccordionSection>

            <AccordionSection
              title="Customer and Bicycle"
              isOpen={openSections.customerBicycle}
              onToggle={() => toggleSection('customerBicycle')}
              icon={<UserCircle />}
            >
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Customer Information</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-500">Name</label>
                        <p className="mt-1 text-gray-900">{visit.customerName}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-500">Service Object</label>
                        <p className="mt-1 text-gray-900">{visit.serviceObject}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-500">Phone Number</label>
                        <p className="mt-1 text-gray-900">{visit.phoneNumber}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-500">Email</label>
                        <p className="mt-1 text-gray-900">{visit.email}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </AccordionSection>

            <AccordionSection
              title="Schedule and Status"
              isOpen={openSections.scheduleStatus}
              onToggle={() => toggleSection('scheduleStatus')}
              icon={<Calendar />}
            >
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Intake Date</label>
                    <p className="mt-1 text-gray-900">{formatDate(visit.intakeDate)}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Release Date</label>
                    <p className="mt-1 text-gray-900">{formatDate(visit.releaseDate)}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Status</label>
                    <span
                      className="mt-1 inline-flex px-3 py-1 rounded-full text-sm font-medium"
                      style={{
                        backgroundColor: `${status?.color}20`,
                        color: status?.color
                      }}
                    >
                      {status?.name}
                    </span>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Assigned Mechanic</label>
                    <p className="mt-1 text-gray-900">{mechanic?.name}</p>
                  </div>
                </div>
              </div>
            </AccordionSection>

            <AccordionSection
              title="Recommendations"
              isOpen={openSections.recommendations}
              onToggle={() => toggleSection('recommendations')}
              icon={<Lightbulb />}
            >
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Additional Recommendations</h3>
                  <p className="p-3 bg-gray-50 rounded-lg text-gray-900">
                    {visit.recommendations || 'No additional recommendations provided.'}
                  </p>
                </div>
              </div>
            </AccordionSection>

            <AccordionSection
              title="Discount"
              isOpen={openSections.costSummary}
              onToggle={() => toggleSection('costSummary')}
              icon={<Receipt />}
            >
              <div className="space-y-4">
                <div className="p-4 bg-gray-50 rounded-lg space-y-3">
                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-medium text-gray-700">Services Subtotal</h3>
                    <span className="font-medium">${servicesTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm text-red-600">
                    <span>Service Discount ({serviceDiscount}%)</span>
                    <span>-${serviceDiscountAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                    <span className="text-sm font-medium text-gray-700">Services Total</span>
                    <span className="font-medium">${servicesAfterDiscount.toFixed(2)}</span>
                  </div>
                </div>

                <div className="p-4 bg-gray-50 rounded-lg space-y-3">
                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-medium text-gray-700">Parts Subtotal</h3>
                    <span className="font-medium">${partsTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm text-red-600">
                    <span>Parts Discount ({partsDiscount}%)</span>
                    <span>-${partsDiscountAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                    <span className="text-sm font-medium text-gray-700">Parts Total</span>
                    <span className="font-medium">${partsAfterDiscount.toFixed(2)}</span>
                  </div>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg space-y-3">
                  <div className="flex justify-between items-center text-sm text-red-600">
                    <span>Total Discount</span>
                    <span>-${totalDiscount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-blue-200">
                    <h3 className="text-lg font-semibold text-blue-900">Final Total</h3>
                    <span className="text-lg font-semibold text-blue-600">
                      ${totalAfterDiscount.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </AccordionSection>
          </div>
        )}

        {activeTab === 'share' && (
          <div className="space-y-6 px-4 sm:px-0">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">Share Visit Details</h2>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Visit Link
                  </label>
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 bg-gray-50 px-4 py-2 rounded-lg text-gray-600 break-all">
                      {visitUrl}
                    </div>
                    <button
                      onClick={copyToClipboard}
                      className="p-2 text-gray-600 hover:text-blue-600 rounded-lg hover:bg-gray-100"
                      title="Copy link"
                    >
                      {copied ? <Check className="h-5 w-5 text-green-600" /> : <Copy className="h-5 w-5" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    QR Code
                  </label>
                  <div className="flex justify-center p-4 bg-white border rounded-lg">
                    {qrCodeUrl && (
                      <img 
                        src={qrCodeUrl} 
                        alt="Visit QR Code"
                        className="w-48 h-48"
                      />
                    )}
                  </div>
                  <p className="text-sm text-gray-500 text-center">
                    Scan this QR code to access visit details
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Share Options
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <button className="flex items-center justify-center space-x-2 px-4 py-2 border rounded-lg hover:bg-gray-50">
                      <MessageSquare className="h-5 w-5 text-gray-600" />
                      <span>Send via SMS</span>
                    </button>
                    <button className="flex items-center justify-center space-x-2 px-4 py-2 border rounded-lg hover:bg-gray-50">
                      <LinkIcon className="h-5 w-5 text-gray-600" />
                      <span>Share via Email</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'communication' && (
          <div className="space-y-6 px-4 sm:px-0">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">SMS</h2>
              
              <div className="space-y-4">
                {/* Confirmation */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-gray-900">Receive confirmation</h3>
                    {visit.smsSent?.confirmation ? (
                      <button
                        onClick={() => handleSendSMS('confirmation')}
                        className="flex items-center px-3 py-1 border border-blue-600 text-blue-600 rounded-md hover:bg-blue-50"
                      >
                        <Send className="h-4 w-4 mr-1" />
                        Resend
                      </button>
                    ) : (
                      <button
                        onClick={() => handleSendSMS('confirmation')}
                        className="flex items-center px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                      >
                        <Send className="h-4 w-4 mr-1" />
                        Send
                      </button>
                    )}
                  </div>
                  {visit.smsSent?.confirmation && (
                    <div className="mt-2 text-sm text-gray-600">
                      Last sent: {formatSentDate(visit.smsSent.confirmation.date)}
                    </div>
                  )}
                  <button
                    onClick={() => handleEditMessage('confirmation')}
                    className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                  >
                    Edit message
                  </button>
                </div>

                {/* Summary with price */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-gray-900">Summary with price</h3>
                    <button
                      onClick={() => handleSendSMS('summaryWithPrice')}
                      className="flex items-center px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      <Send className="h-4 w-4 mr-1" />
                      Send
                    </button>
                  </div>
                  <button
                    onClick={() => handleEditMessage('summaryWithPrice')}
                    className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                  >
                    Edit message
                  </button>
                </div>

                {/* Summary without price */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-gray-900">Summary without price</h3>
                    <button
                      onClick={() => handleSendSMS('summaryWithoutPrice')}
                      className="flex items-center px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      <Send className="h-4 w-4 mr-1" />
                      Send
                    </button>
                  </div>
                  <button
                    onClick={() => handleEditMessage('summaryWithoutPrice')}
                    className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                  >
                    Edit message
                  </button>
                </div>

                {/* Reminder about visit */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-gray-900">Reminder about visit</h3>
                    <button
                      onClick={() => handleSendSMS('reminderVisit')}
                      className="flex items-center px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      <Send className="h-4 w-4 mr-1" />
                      Send
                    </button>
                  </div>
                  <button
                    onClick={() => handleEditMessage('reminderVisit')}
                    className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                  >
                    Edit message
                  </button>
                </div>

                {/* Reminder about collection */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-gray-900">Reminder about collection</h3>
                    <button
                      onClick={() => handleSendSMS('reminderCollection')}
                      className="flex items-center px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      <Send className="h-4 w-4 mr-1" />
                      Send
                    </button>
                  </div>
                  <button
                    onClick={() => handleEditMessage('reminderCollection')}
                    className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                  >
                    Edit message
                  </button>
                </div>

                {/* Collection confirmation */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-gray-900">Collection confirmation</h3>
                    <button
                      onClick={() => handleSendSMS('collectionConfirmation')}
                      className="flex items-center px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      <Send className="h-4 w-4 mr-1" />
                      Send
                    </button>
                  </div>
                  <button
                    onClick={() => handleEditMessage('collectionConfirmation')}
                    className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                  >
                    Edit message
                  </button>
                </div>
              </div>
            </div>

            {/* Edit Message Modal */}
            {editMessageModal.isOpen && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white rounded-lg p-6 max-w-lg w-full m-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Edit Message
                  </h3>
                  <textarea
                    value={editMessageModal.message}
                    onChange={(e) => setEditMessageModal(prev => ({
                      ...prev,
                      message: e.target.value
                    }))}
                    className="w-full h-32 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 mb-4"
                  />
                  <div className="flex justify-end space-x-3">
                    <button
                      onClick={() => setEditMessageModal({ isOpen: false, type: '', message: '' })}
                      className="px-4 py-2 border rounded-md hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        // Save the edited message logic here
                        setEditMessageModal({ isOpen: false, type: '', message: '' })
                      }}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      Save Changes
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  )
}