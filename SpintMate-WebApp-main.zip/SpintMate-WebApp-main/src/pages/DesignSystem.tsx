import React, { useState } from 'react'
import { TabGroup } from '../components/core/TabGroup'
import { DataTable } from '../components/data/DataTable'
import { Menu, Bell, Search, Plus, ChevronDown, Calendar, Upload, Check, X, AlertCircle, MessageSquare, Link, QrCode, Loader2 } from 'lucide-react'
import { customerInfos } from '../data/constants'

export function DesignSystem() {
  const [activeTab, setActiveTab] = useState('navigation')
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [showToast, setShowToast] = useState(false)

  const tabs = [
    { id: 'navigation', label: 'Navigation & Layout' },
    { id: 'data', label: 'Data Display' },
    { id: 'input', label: 'Input & Forms' },
    { id: 'search', label: 'Search & Filters' },
    { id: 'action', label: 'Actions' },
    { id: 'management', label: 'Management' },
    { id: 'communication', label: 'Communication' },
    { id: 'utility', label: 'Utility' }
  ]

  const tableColumns = [
    { header: 'Name', accessor: 'name' },
    { header: 'Email', accessor: 'email' },
    { header: 'Phone', accessor: 'phoneNumber' }
  ]

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <header className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">Design System</h1>
          <p className="mt-2 text-gray-600">A comprehensive collection of UI components</p>
        </header>

        <TabGroup tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

        <div className="bg-white rounded-lg shadow-sm p-6 space-y-12">
          {activeTab === 'navigation' && (
            <div className="space-y-8">
              {/* Navigation Menu */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Navigation Menu</h2>
                <div className="flex bg-white border rounded-lg">
                  <div className="w-64 border-r p-4">
                    <div className="flex items-center space-x-2 p-2 rounded hover:bg-gray-100 cursor-pointer">
                      <Menu className="h-5 w-5 text-gray-500" />
                      <span>Dashboard</span>
                    </div>
                  </div>
                  <div className="flex-1 p-4">Content Area</div>
                </div>
              </section>

              {/* Dashboard Panel */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Dashboard Overview</h2>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-white p-4 rounded-lg border">
                    <h3 className="font-medium text-gray-700">Total Visits</h3>
                    <p className="text-2xl font-bold">128</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg border">
                    <h3 className="font-medium text-gray-700">Active Visits</h3>
                    <p className="text-2xl font-bold">24</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg border">
                    <h3 className="font-medium text-gray-700">Completed Today</h3>
                    <p className="text-2xl font-bold">12</p>
                  </div>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'data' && (
            <div className="space-y-8">
              {/* Data Table */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Data Table</h2>
                <DataTable data={customerInfos} columns={tableColumns} />
              </section>

              {/* Status Badge */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Status Badges</h2>
                <div className="flex space-x-4">
                  <span className="px-2 py-1 rounded-full text-sm bg-green-100 text-green-800">Active</span>
                  <span className="px-2 py-1 rounded-full text-sm bg-yellow-100 text-yellow-800">Pending</span>
                  <span className="px-2 py-1 rounded-full text-sm bg-red-100 text-red-800">Cancelled</span>
                </div>
              </section>

              {/* Timeline */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Timeline</h2>
                <div className="space-y-4">
                  <div className="flex">
                    <div className="flex flex-col items-center">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <div className="w-0.5 h-full bg-blue-200"></div>
                    </div>
                    <div className="ml-4">
                      <p className="font-medium">Visit Created</p>
                      <p className="text-sm text-gray-500">2 hours ago</p>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'input' && (
            <div className="space-y-8">
              {/* Form Container */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Form Components</h2>
                <form className="space-y-4 max-w-lg">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea
                      className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                      rows={3}
                      placeholder="Enter description"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500">
                      <option>Active</option>
                      <option>Pending</option>
                      <option>Completed</option>
                    </select>
                  </div>
                </form>
              </section>
            </div>
          )}

          {activeTab === 'search' && (
            <div className="space-y-8">
              {/* Search Bar */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Search Components</h2>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="search"
                    className="w-full pl-10 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                    placeholder="Search visits..."
                  />
                </div>
              </section>

              {/* Filter Tags */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Filter Tags</h2>
                <div className="flex flex-wrap gap-2">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100">
                    Status: Active
                    <button className="ml-2">
                      <X className="h-4 w-4 text-gray-500" />
                    </button>
                  </span>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'action' && (
            <div className="space-y-8">
              {/* Buttons */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Action Buttons</h2>
                <div className="space-y-4">
                  <div className="flex space-x-4">
                    <button className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
                      Primary Action
                    </button>
                    <button className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
                      Secondary Action
                    </button>
                  </div>
                  <div className="fixed bottom-8 right-8">
                    <button className="p-3 bg-blue-500 text-white rounded-full hover:bg-blue-600 shadow-lg">
                      <Plus className="h-6 w-6" />
                    </button>
                  </div>
                </div>
              </section>

              {/* Modal */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Modal Dialog</h2>
                <button
                  onClick={() => setIsModalOpen(true)}
                  className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
                >
                  Delete Item
                </button>

                {isModalOpen && (
                  <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                    <div className="bg-white p-6 rounded-lg max-w-md">
                      <h3 className="text-lg font-medium mb-4">Confirm Deletion</h3>
                      <p className="text-gray-600 mb-6">Are you sure you want to delete this item?</p>
                      <div className="flex justify-end space-x-4">
                        <button
                          onClick={() => setIsModalOpen(false)}
                          className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => setIsModalOpen(false)}
                          className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </section>
            </div>
          )}

          {activeTab === 'management' && (
            <div className="space-y-8">
              {/* CRUD Interface */}
              <section>
                <h2 className="text-xl font-semibold mb-4">CRUD Interface</h2>
                <div className="border rounded-lg overflow-hidden">
                  <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
                    <h3 className="font-medium">Manage Items</h3>
                    <button className="px-3 py-1 bg-blue-500 text-white rounded-md hover:bg-blue-600">
                      Add New
                    </button>
                  </div>
                  <div className="p-4">
                    <div className="space-y-2">
                      {['Item 1', 'Item 2', 'Item 3'].map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-2 hover:bg-gray-50">
                          <span>{item}</span>
                          <div className="space-x-2">
                            <button className="text-blue-500 hover:text-blue-600">Edit</button>
                            <button className="text-red-500 hover:text-red-600">Delete</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'communication' && (
            <div className="space-y-8">
              {/* Toast Notification */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Toast Notifications</h2>
                <button
                  onClick={() => {
                    setShowToast(true)
                    setTimeout(() => setShowToast(false), 3000)
                  }}
                  className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                >
                  Show Toast
                </button>

                {showToast && (
                  <div className="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center">
                    <Check className="h-5 w-5 mr-2" />
                    Operation completed successfully
                  </div>
                )}
              </section>

              {/* Communication Tools */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Communication Tools</h2>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <MessageSquare className="h-5 w-5 text-gray-500" />
                      <span className="font-medium">SMS Preview</span>
                    </div>
                    <p className="text-gray-600">Your appointment is scheduled for tomorrow at 2 PM.</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Link className="h-5 w-5 text-gray-500" />
                      <span className="font-medium">Share Link</span>
                    </div>
                    <input
                      type="text"
                      value="https://example.com/visit/123"
                      readOnly
                      className="w-full px-3 py-2 bg-gray-50 rounded border"
                    />
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <QrCode className="h-5 w-5 text-gray-500" />
                      <span className="font-medium">QR Code</span>
                    </div>
                    <div className="w-32 h-32 bg-gray-100 rounded flex items-center justify-center">
                      QR Preview
                    </div>
                  </div>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'utility' && (
            <div className="space-y-8">
              {/* Loading States */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Loading States</h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-center p-8 border rounded-lg">
                    <Loader2 className="h-8 w-8 text-blue-500 animate-spin" />
                  </div>
                </div>
              </section>

              {/* Empty States */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Empty States</h2>
                <div className="text-center p-8 border rounded-lg">
                  <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">No items found</h3>
                  <p className="text-gray-500 mt-2">Try adjusting your search or filter to find what you're looking for.</p>
                </div>
              </section>

              {/* Breadcrumbs */}
              <section>
                <h2 className="text-xl font-semibold mb-4">Breadcrumb Navigation</h2>
                <div className="flex items-center space-x-2 text-sm">
                  <a href="#" className="text-gray-500 hover:text-gray-700">Home</a>
                  <span className="text-gray-400">/</span>
                  <a href="#" className="text-gray-500 hover:text-gray-700">Visits</a>
                  <span className="text-gray-400">/</span>
                  <span className="text-gray-900">Details</span>
                </div>
              </section>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}