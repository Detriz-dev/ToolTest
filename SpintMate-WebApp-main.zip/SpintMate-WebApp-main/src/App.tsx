import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Layout } from './components/core/Layout'
import { Dashboard } from './pages/Dashboard'
import { DesignSystem } from './pages/DesignSystem'
import { CustomerVisits } from './pages/CustomerVisits'
import { CustomerVisit } from './pages/CustomerVisit'
import { AllVisits } from './pages/Search'
import { SearchVisit } from './pages/SearchVisit'
import { Manage } from './pages/Manage'
import { Mechanics } from './pages/Mechanics'
import { VisitLabels } from './pages/VisitLabels'
import { ServiceSubjects } from './pages/ServiceSubjects'
import { ServiceParts } from './pages/ServiceParts'
import { AddVisit } from './pages/AddVisit'
import { EditVisit } from './pages/EditVisit'
import { TotalVisits } from './pages/TotalVisits'
import { SmsTemplates } from './pages/SmsTemplates'
import { Settings } from './pages/Settings'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/design-system" element={<DesignSystem />} />
          <Route path="/customer-visits" element={<CustomerVisits />} />
          <Route path="/customer-visit/:id" element={<CustomerVisit />} />
          <Route path="/customer-visit/:id/edit" element={<EditVisit />} />
          <Route path="/all-visits" element={<AllVisits />} />
          <Route path="/search" element={<AllVisits />} />
          <Route path="/search-visit" element={<SearchVisit />} />
          <Route path="/manage" element={<Manage />} />
          <Route path="/mechanics" element={<Mechanics />} />
          <Route path="/visit-labels" element={<VisitLabels />} />
          <Route path="/service-subjects" element={<ServiceSubjects />} />
          <Route path="/service-parts" element={<ServiceParts />} />
          <Route path="/add-visit" element={<AddVisit />} />
          <Route path="/total-visits" element={<TotalVisits />} />
          <Route path="/sms-templates" element={<SmsTemplates />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App